{
  lib,
  stdenv,
  cairo,
  dbus,
  gdk-pixbuf,
  glib,
  gobject-introspection,
  harfbuzz,
  libdrm,
  libinput,
  librsvg,
  libxcb,
  libxcb-util,
  libxcb-wm,
  libxkbcommon,
  luajit,
  makeWrapper,
  meson,
  ninja,
  pam,
  pango,
  pkg-config,
  wayland,
  wayland-protocols,
  wayland-scanner,
  wlroots_0_19,
  xwayland,
  gtk3Support ? true,
  gtk3 ? null,
  extraGIPackages ? [ ],
  extraLuaPackages ? (_: [ ]),
}:

assert gtk3Support -> gtk3 != null;

let
  luaEnv = luajit.withPackages (
    ps:
    with ps;
    [
      lgi
      ldbus
    ]
    ++ (extraLuaPackages ps)
  );
in
stdenv.mkDerivation {
  pname = "somewm";
  version = "dev";

  src = ./.;

  strictDeps = true;

  nativeBuildInputs = [
    gobject-introspection
    makeWrapper
    meson
    ninja
    pkg-config
    wayland-scanner
  ];

  buildInputs = [
    cairo
    dbus
    gdk-pixbuf
    glib
    harfbuzz
    libdrm
    libinput
    librsvg
    libxkbcommon
    luajit
    luaEnv
    pam
    pango
    wayland
    wayland-protocols
    wlroots_0_19
    libxcb
    libxcb-wm
    libxcb-util
    xwayland
  ]
  ++ lib.optional gtk3Support gtk3;

  mesonFlags = [ "-Dsystemd=disabled" ];

  postFixup =
    let
      giPackages = [
        gdk-pixbuf
        glib.out
        gobject-introspection
        harfbuzz.out
        librsvg.out
        pango.out
      ]
      ++ lib.optional gtk3Support gtk3.out
      ++ extraGIPackages;
      giTypelibPath = lib.strings.concatMapStringsSep ":" (p: "${p}/lib/girepository-1.0") giPackages;
    in
    ''
      wrapProgram $out/bin/somewm \
        --prefix GI_TYPELIB_PATH : "${giTypelibPath}" \
        --prefix LUA_PATH : "${luaEnv}/share/lua/${luaEnv.luaversion}/?.lua;${luaEnv}/share/lua/${luaEnv.luaversion}/?/init.lua" \
        --prefix LUA_CPATH : "${luaEnv}/lib/lua/${luaEnv.luaversion}/?.so"
    '';

  passthru.providedSessions = [ "somewm" ];

  meta = with lib; {
    description = "AwesomeWM ported to Wayland - 100% Lua API compatible";
    homepage = "https://github.com/trip-zip/somewm";
    license = licenses.gpl3;
    platforms = platforms.linux;
    mainProgram = "somewm";
  };
}
