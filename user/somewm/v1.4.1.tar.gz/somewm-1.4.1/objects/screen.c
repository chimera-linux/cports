#include "screen.h"
#include "output.h"
#include "client.h"
#include "drawin.h"
#include "drawable.h"
#include "signal.h"
#include "luaa.h"
#include "common/luaclass.h"
#include "common/luaobject.h"
#include "../somewm_api.h"
#include "../globalconf.h"
#include "common/util.h"
#include "../x11_compat.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <cairo.h>
#include <drm_fourcc.h>
#include <wlr/types/wlr_scene.h>
#include <wlr/types/wlr_output.h>
#include <wlr/interfaces/wlr_buffer.h>
#include <wlr/render/wlr_renderer.h>
#include <wlr/render/wlr_texture.h>
#include <math.h>

/* AwesomeWM-compatible screen class */
static lua_class_t screen_class;
LUA_OBJECT_FUNCS(screen_class, screen_t, screen)

/* External reference to selected monitor */
extern Monitor *selmon;
extern struct wl_list mons;  /* Global monitor list from somewm.c */

/* External references for screenshot support */
extern struct wlr_scene *scene;
extern struct wlr_renderer *drw;

/* Global array of screen objects - stores Lua registry references */
static int *screen_refs = NULL;
static size_t screen_count = 0;
static size_t screen_capacity = 0;

/* Primary screen tracking */
static screen_t *primary_screen = NULL;

/* Track whether initial screen scanning is complete (for hotplug detection) */
static bool screens_scanned = false;

/* Forward declarations for signal array helpers (from signal.c) */
extern void signal_array_init(signal_array_t *arr);
extern void signal_array_wipe(signal_array_t *arr);

/** Reset screen_refs array for hot-reload.
 * Unrefs all screen objects from the old Lua registry and resets the array.
 * Must be called BEFORE lua_close() so the unrefs happen against the live state.
 */
void
luaA_screen_refs_reset(void)
{
	screen_count = 0;
	/* Keep allocated capacity for reuse. screen_refs entries are Lua registry
	 * refs from the old state - they become invalid after lua_close(). */
	primary_screen = NULL;
	screens_scanned = false;
}

/** Get all screen objects for hot-reload snapshot.
 * \param L Lua state (for accessing registry)
 * \param out_screens Output array (caller-allocated, at least *out_count entries)
 * \param out_count In: size of out_screens array. Out: actual number of screens.
 */
void
luaA_screen_get_all(lua_State *L, screen_t **out_screens, int *out_count)
{
	int max = *out_count;
	int count = 0;
	size_t i;

	for (i = 0; i < screen_count && count < max; i++) {
		lua_rawgeti(L, LUA_REGISTRYINDEX, screen_refs[i]);
		screen_t *s = (screen_t *)lua_touserdata(L, -1);
		lua_pop(L, 1);
		if (s) {
			out_screens[count++] = s;
		}
	}
	*out_count = count;
}

/* ========================================================================
 * Screen object management
 * ======================================================================== */

/** Create a new screen object
 * \param L Lua state
 * \param m Monitor pointer
 * \param index Screen index (1-based)
 * \return Pointer to new screen object
 */
screen_t *
luaA_screen_new(lua_State *L, Monitor *m, int index)
{
	screen_t *screen;
	int ref;

	/* Create screen object using AwesomeWM pattern (from screen_add) */
	screen = screen_new(L);
	lua_pushvalue(L, -1);    /* Duplicate for luaA_object_ref (will be popped) */
	luaA_object_ref(L, -1);  /* Store in object registry (pops the duplicate) */

	/* Initialize screen fields (like AwesomeWM's screen_scan_randr_monitors) */
	screen->monitor = m;
	screen->index = index;
	screen->valid = true;
	screen->lifecycle = SCREEN_LIFECYCLE_C;
	screen->name = NULL;
	screen->virtual_output = NULL;
	some_monitor_get_geometry(m, &screen->geometry);
	screen->workarea = screen->geometry;

	/* Store reference in regular registry to prevent GC and allow retrieval */
	lua_pushvalue(L, -1);
	ref = luaL_ref(L, LUA_REGISTRYINDEX);

	log_debug("screen created: index=%d geometry=%dx%d+%d+%d",
	          index, screen->geometry.width, screen->geometry.height,
	          screen->geometry.x, screen->geometry.y);

	/* Add reference to global screen array */
	if (screen_count >= screen_capacity) {
		size_t new_cap = screen_capacity == 0 ? 4 : screen_capacity * 2;
		int *new_refs = realloc(screen_refs, new_cap * sizeof(int));
		if (!new_refs) {
			fprintf(stderr, "somewm: failed to allocate screen array\n");
			luaL_unref(L, LUA_REGISTRYINDEX, ref);
			return NULL;
		}
		screen_refs = new_refs;
		screen_capacity = new_cap;
	}
	screen_refs[screen_count++] = ref;

	/* Screen userdata is still on stack for caller */
	return screen;
}

/** Push a screen object onto the Lua stack
 * \param L Lua state
 * \param screen Screen object to push
 */
void
luaA_screen_push(lua_State *L, screen_t *screen)
{
	size_t i;

	if (!screen) {
		lua_pushnil(L);
		return;
	}

	/* Find screen in global array by comparing the screen pointer */
	for (i = 0; i < screen_count; i++) {
		screen_t *s;

		/* Get screen from registry */
		lua_rawgeti(L, LUA_REGISTRYINDEX, screen_refs[i]);
		s = (screen_t *)lua_touserdata(L, -1);

		if (s == screen) {
			/* Found it - userdata is now on stack */
			return;
		}

		/* Not this one, pop it */
		lua_pop(L, 1);
	}

	/* Screen not found - this shouldn't happen */
	fprintf(stderr, "somewm: warning: screen not found in registry\n");
	lua_pushnil(L);
}

/** Check if argument is a screen object and return it
 * \param L Lua state
 * \param idx Stack index
 * \return Screen object pointer, or NULL on error
 */
screen_t *
luaA_checkscreen(lua_State *L, int idx)
{
	if (lua_isnumber(L, idx))
	{
		int screen = lua_tointeger(L, idx);
		if (screen < 1 || screen > (int)screen_count)
		{
			luaA_warn(L, "invalid screen number: %d (of %d existing)",
			          screen, (int)screen_count);
			lua_pushnil(L);
			return NULL;
		}
		lua_rawgeti(L, LUA_REGISTRYINDEX, screen_refs[screen - 1]);
		screen_t *s = (screen_t *)lua_touserdata(L, -1);
		lua_pop(L, 1);
		return s;
	}
	return (screen_t *)luaA_checkudata(L, idx, &screen_class);
}

/** Try to convert argument to screen object
 * \param L Lua state
 * \param idx Stack index
 * \return Screen object pointer, or NULL if not a screen
 */
screen_t *
luaA_toscreen(lua_State *L, int idx)
{
	/* Use AwesomeWM class system for type checking */
	return (screen_t *)luaA_toudata(L, idx, &screen_class);
}

/** Find a screen object by its Monitor pointer
 * \param L Lua state
 * \param m Monitor pointer to search for
 * \return Screen object pointer, or NULL if not found
 */
screen_t *
luaA_screen_get_by_monitor(lua_State *L, Monitor *m)
{
	size_t i;

	if (!m)
		return NULL;

	/* Search through all screens */
	for (i = 0; i < screen_count; i++) {
		screen_t *screen;

		/* Get screen from registry */
		lua_rawgeti(L, LUA_REGISTRYINDEX, screen_refs[i]);
		screen = (screen_t *)lua_touserdata(L, -1);
		lua_pop(L, 1);

		if (screen && screen->monitor == m)
			return screen;
	}

	return NULL;
}

screen_t *
luaA_screen_get_by_virtual_output(lua_State *L, struct output_t *o)
{
	size_t i;

	if (!o)
		return NULL;

	for (i = 0; i < screen_count; i++) {
		screen_t *screen;
		lua_rawgeti(L, LUA_REGISTRYINDEX, screen_refs[i]);
		screen = (screen_t *)lua_touserdata(L, -1);
		lua_pop(L, 1);

		if (screen && screen->virtual_output == o)
			return screen;
	}

	return NULL;
}

/** Emit "_added" signal for a screen object
 * This is called after a screen is created and should trigger
 * awful.screen's signal bridge to emit request::desktop_decoration
 * \param L Lua state
 * \param screen Screen object that was added
 *
 * Note: This emits an instance-level "_added" signal on the screen object
 */
void
screen_added(lua_State *L, screen_t *screen)
{
	screen->workarea = screen->geometry;
	screen->valid = true;
	luaA_object_push(L, screen);
	luaA_object_emit_signal(L, -1, "_added", 0);
	lua_pop(L, 1);
}

/** Emit screen::scanning class signal */
void
screen_emit_scanning(void)
{
	lua_State *L = globalconf_get_lua_State();
	luaA_class_emit_signal(L, &screen_class, "scanning", 0);
}

/** Emit screen::scanned class signal */
void
screen_emit_scanned(void)
{
	lua_State *L = globalconf_get_lua_State();
	screens_scanned = true;
	luaA_class_emit_signal(L, &screen_class, "scanned", 0);
}

/** Check if initial screen scanning is complete
 * Used to distinguish startup from hotplug - screens created after scanning
 * need their _added signal emitted immediately.
 */
bool
luaA_screen_scanned_done(void)
{
	return screens_scanned;
}

/** Emit screen::list class signal
 * This notifies Lua code that the screen list has changed.
 * Should be called after screens are added or removed.
 */
void
luaA_screen_emit_list(lua_State *L)
{
	luaA_class_emit_signal(L, &screen_class, "list", 0);
}

/* Forward declaration for viewports function */
static int luaA_screen_viewports(lua_State *L);

/** Emit property::_viewports class signal
 * This notifies Lua code that viewport information has changed.
 * Used by awful.screen.dpi for DPI handling on multi-monitor setups.
 */
void
luaA_screen_emit_viewports(lua_State *L)
{
	/* Push the viewports table onto stack as signal argument */
	luaA_screen_viewports(L);
	luaA_class_emit_signal(L, &screen_class, "property::_viewports", 1);
}

/** Emit primary_changed signal on a screen object
 * This notifies Lua code that the screen's primary status changed.
 */
void
luaA_screen_emit_primary_changed(lua_State *L, screen_t *screen)
{
	if (!screen || !screen->valid)
		return;
	luaA_screen_push(L, screen);
	luaA_object_emit_signal(L, -1, "primary_changed", 0);
	lua_pop(L, 1);
}

/** Find screen by coordinates (for client relocation on screen removal)
 * Returns the screen that contains the given point, or the nearest screen
 * \param L Lua state
 * \param x X coordinate
 * \param y Y coordinate
 * \return Screen containing or nearest to the point, or NULL
 */
screen_t *
luaA_screen_getbycoord(lua_State *L, int x, int y)
{
	screen_t *nearest = NULL;
	unsigned int nearest_dist = UINT_MAX;
	size_t i;

	for (i = 0; i < screen_count; i++) {
		screen_t *s;
		unsigned int dist;
		int dx, dy;

		lua_rawgeti(L, LUA_REGISTRYINDEX, screen_refs[i]);
		s = (screen_t *)lua_touserdata(L, -1);
		lua_pop(L, 1);

		if (!s || !s->valid)
			continue;

		/* Check if point is inside this screen */
		if (x >= s->geometry.x && x < s->geometry.x + s->geometry.width &&
		    y >= s->geometry.y && y < s->geometry.y + s->geometry.height)
			return s;

		/* Calculate distance to screen center for fallback */
		dx = x - (s->geometry.x + s->geometry.width / 2);
		dy = y - (s->geometry.y + s->geometry.height / 2);
		dist = (unsigned int)(dx * dx + dy * dy);

		if (dist < nearest_dist) {
			nearest_dist = dist;
			nearest = s;
		}
	}

	return nearest;
}

/** Handle screen removal (AwesomeWM pattern)
 * Called when a monitor is disconnected. Emits "removed" signal on the screen
 * instance and relocates clients to the nearest screen.
 * \param L Lua state
 * \param screen Screen being removed
 */
void
screen_removed(lua_State *L, screen_t *screen)
{
	size_t i;

	if (!screen || !screen->valid)
		return;

	log_debug("screen removed: index=%d", screen->index);

	/* Step 1: Emit instance-level "removed" signal FIRST
	 * This allows Lua code to handle cleanup before screen is invalidated */
	luaA_screen_push(L, screen);
	luaA_object_emit_signal(L, -1, "removed", 0);
	lua_pop(L, 1);

	/* Step 2: Clear primary if this was it */
	if (primary_screen == screen)
		primary_screen = NULL;

	/* Step 3: Move clients to nearest screen
	 * Note: This uses the client's center point to find the nearest screen */
	foreach(c, globalconf.clients) {
		if ((*c)->screen == screen) {
			int cx = (*c)->geometry.x + (*c)->geometry.width / 2;
			int cy = (*c)->geometry.y + (*c)->geometry.height / 2;
			screen_t *new_screen = luaA_screen_getbycoord(L, cx, cy);

			if (new_screen && new_screen != screen) {
				screen_client_moveto(*c, new_screen, false);
			}
		}
	}

	/* Step 4: Mark screen as invalid */
	screen->valid = false;
	screen->monitor = NULL;

	/* Step 5: Remove from screen array and re-index remaining screens */
	for (i = 0; i < screen_count; i++) {
		screen_t *s;

		lua_rawgeti(L, LUA_REGISTRYINDEX, screen_refs[i]);
		s = (screen_t *)lua_touserdata(L, -1);
		lua_pop(L, 1);

		if (s == screen) {
			/* Found the screen - remove its reference */
			luaL_unref(L, LUA_REGISTRYINDEX, screen_refs[i]);

			/* Shift remaining references down */
			memmove(&screen_refs[i], &screen_refs[i + 1],
			        (screen_count - i - 1) * sizeof(int));
			screen_count--;

			/* Re-index remaining screens */
			for (size_t j = i; j < screen_count; j++) {
				screen_t *rs;
				lua_rawgeti(L, LUA_REGISTRYINDEX, screen_refs[j]);
				rs = (screen_t *)lua_touserdata(L, -1);
				lua_pop(L, 1);
				if (rs)
					rs->index = (int)(j + 1);
			}
			break;
		}
	}

	/* Step 6: Emit class-level "list" signal to notify of screen array change */
	luaA_class_emit_signal(L, &screen_class, "list", 0);
}

/** Get primary screen
 * \param L Lua state
 * \return Primary screen or NULL if none set
 */
screen_t *
luaA_screen_get_primary_screen(lua_State *L)
{
	screen_t *s;

	/* If primary is set and still valid, return it */
	if (primary_screen && primary_screen->valid)
		return primary_screen;

	/* Otherwise return first screen if any exist */
	if (screen_count > 0) {
		lua_rawgeti(L, LUA_REGISTRYINDEX, screen_refs[0]);
		s = (screen_t *)lua_touserdata(L, -1);
		lua_pop(L, 1);
		return s;
	}

	return NULL;
}

/** Emit _added signal for all existing screens
 * This is called after rc.lua loads to trigger screen initialization
 */
void
luaA_screen_emit_all_added(lua_State *L)
{
	size_t i;

	for (i = 0; i < screen_count; i++) {
		screen_t *screen;

		/* Get screen from registry */
		lua_rawgeti(L, LUA_REGISTRYINDEX, screen_refs[i]);
		screen = (screen_t *)lua_touserdata(L, -1);
		lua_pop(L, 1);

		if (screen && screen->valid) {
			screen_added(L, screen);
		}
	}
}

/* ========================================================================
 * Screen property updates and change detection
 * ======================================================================== */

/** Helper to push wlr_box as Lua table */
static void
push_wlr_box(lua_State *L, struct wlr_box *box)
{
	lua_newtable(L);
	lua_pushinteger(L, box->x);
	lua_setfield(L, -2, "x");
	lua_pushinteger(L, box->y);
	lua_setfield(L, -2, "y");
	lua_pushinteger(L, box->width);
	lua_setfield(L, -2, "width");
	lua_pushinteger(L, box->height);
	lua_setfield(L, -2, "height");
}

/* Note: wlr_box_equal() is provided by wlroots in wlr/util/box.h */

/** Recalculate workarea for a screen including all drawin struts
 * \param L Lua state (unused, kept for compatibility)
 * \param screen Screen to recalculate workarea for
 *
 * Wrapper for screen_update_workarea() for internal use.
 */
static void
luaA_screen_recalculate_workarea(lua_State *L, screen_t *screen)
{
	(void)L;
	screen_update_workarea(screen);
}

/** Update screen geometry from monitor and emit property::geometry if changed
 * \param L Lua state
 * \param screen Screen to update
 *
 * This should be called when the monitor's geometry changes (resolution change, etc.)
 * It will compare the new geometry with the cached value and emit property::geometry
 * with the old geometry if it changed.
 */
void
luaA_screen_update_geometry(lua_State *L, screen_t *screen)
{
	struct wlr_box new_geom;

	if (!screen || !screen->valid || !screen->monitor)
		return;

	/* Get current geometry from monitor */
	some_monitor_get_geometry(screen->monitor, &new_geom);

	/* Check if geometry changed */
	if (!wlr_box_equal(&screen->geometry, &new_geom)) {
		struct wlr_box old_geom = screen->geometry;

		/* Update cached geometry */
		screen->geometry = new_geom;

		/* Wayland-specific: auto-resize visible drawins that filled the old
		 * screen geometry. Handles scale/mode changes that shrink/grow the
		 * logical screen size. AwesomeWM never needs this (no per-output scaling). */
		foreach(item, globalconf.drawins) {
			drawin_t *d = *item;
			if (!d->visible || d->screen != screen)
				continue;
			if (d->x == old_geom.x && d->y == old_geom.y &&
			    d->width == old_geom.width && d->height == old_geom.height) {
				luaA_drawin_set_geometry(L, d,
					new_geom.x, new_geom.y,
					new_geom.width, new_geom.height);
			}
		}

		/* Emit property::geometry signal with old geometry as argument */
		luaA_screen_push(L, screen);
		push_wlr_box(L, &old_geom);
		luaA_object_emit_signal(L, -2, "property::geometry", 1);
		lua_pop(L, 1);  /* Pop screen object */

		/* Recalculate workarea including drawin struts.
		 * We pass NULL as drawin since we want to recalculate for ALL drawins
		 * on this screen, not just one specific drawin. The function will
		 * iterate through globalconf.drawins to find all visible ones. */
		luaA_screen_recalculate_workarea(L, screen);
	}
}

/** Set screen workarea directly and emit property::workarea if changed
 * \param L Lua state
 * \param screen Screen to update
 * \param workarea New workarea to set
 *
 * This is used by Wayland layer shell to set workarea based on exclusive zones.
 * For strut-based workarea calculation, use screen_update_workarea() instead.
 */
void
screen_set_workarea(lua_State *L, screen_t *screen, struct wlr_box *workarea)
{
	struct wlr_box new_workarea;

	if (!screen || !screen->valid)
		return;

	/* If no workarea provided, use current geometry */
	if (workarea) {
		new_workarea = *workarea;
	} else {
		new_workarea = screen->geometry;
	}

	/* Check if workarea changed */
	if (!wlr_box_equal(&screen->workarea, &new_workarea)) {
		struct wlr_box old_workarea = screen->workarea;

		/* Update cached workarea */
		screen->workarea = new_workarea;

		/* Update the C Monitor struct's workarea */
		if (screen->monitor) {
			screen->monitor->w = new_workarea;
		}

		/* Emit property::workarea signal with old workarea as argument */
		luaA_screen_push(L, screen);
		push_wlr_box(L, &old_workarea);
		luaA_object_emit_signal(L, -2, "property::workarea", 1);
		lua_pop(L, 1);  /* Pop screen object */
	}
}

/** Update screen workarea based on all drawin and client struts
 * \param screen Screen to update workarea for
 *
 * This matches AwesomeWM's screen_update_workarea() signature.
 * Aggregates struts from ALL visible drawins and clients on the screen.
 */
void
screen_update_workarea(screen_t *screen)
{
	area_t area = screen->geometry;
	uint16_t top = 0, bottom = 0, left = 0, right = 0;

#define COMPUTE_STRUT(o) \
	{ \
		if((o)->strut.top_start_x || (o)->strut.top_end_x || (o)->strut.top) \
		{ \
			if((o)->strut.top) \
				top = MAX(top, (o)->strut.top); \
			else \
				top = MAX(top, ((o)->geometry.y - area.y) + (o)->geometry.height); \
		} \
		if((o)->strut.bottom_start_x || (o)->strut.bottom_end_x || (o)->strut.bottom) \
		{ \
			if((o)->strut.bottom) \
				bottom = MAX(bottom, (o)->strut.bottom); \
			else \
				bottom = MAX(bottom, (area.y + area.height) - (o)->geometry.y); \
		} \
		if((o)->strut.left_start_y || (o)->strut.left_end_y || (o)->strut.left) \
		{ \
			if((o)->strut.left) \
				left = MAX(left, (o)->strut.left); \
			else \
				left = MAX(left, ((o)->geometry.x - area.x) + (o)->geometry.width); \
		} \
		if((o)->strut.right_start_y || (o)->strut.right_end_y || (o)->strut.right) \
		{ \
			if((o)->strut.right) \
				right = MAX(right, (o)->strut.right); \
			else \
				right = MAX(right, (area.x + area.width) - (o)->geometry.x); \
		} \
	}

	foreach(c, globalconf.clients)
		if((*c)->screen == screen && client_isvisible(*c))
			COMPUTE_STRUT(*c)

#undef COMPUTE_STRUT

	/* Drawin uses separate x/y/width/height fields instead of geometry struct */
#define COMPUTE_DRAWIN_STRUT(d) \
	{ \
		if((d)->strut.top_start_x || (d)->strut.top_end_x || (d)->strut.top) \
		{ \
			if((d)->strut.top) \
				top = MAX(top, (d)->strut.top); \
			else \
				top = MAX(top, ((d)->y - area.y) + (d)->height); \
		} \
		if((d)->strut.bottom_start_x || (d)->strut.bottom_end_x || (d)->strut.bottom) \
		{ \
			if((d)->strut.bottom) \
				bottom = MAX(bottom, (d)->strut.bottom); \
			else \
				bottom = MAX(bottom, (area.y + area.height) - (d)->y); \
		} \
		if((d)->strut.left_start_y || (d)->strut.left_end_y || (d)->strut.left) \
		{ \
			if((d)->strut.left) \
				left = MAX(left, (d)->strut.left); \
			else \
				left = MAX(left, ((d)->x - area.x) + (d)->width); \
		} \
		if((d)->strut.right_start_y || (d)->strut.right_end_y || (d)->strut.right) \
		{ \
			if((d)->strut.right) \
				right = MAX(right, (d)->strut.right); \
			else \
				right = MAX(right, (area.x + area.width) - (d)->x); \
		} \
	}

	foreach(drawin, globalconf.drawins)
		if((*drawin)->visible)
		{
			screen_t *d_screen = screen_getbycoord((*drawin)->x, (*drawin)->y);
			if (d_screen == screen)
				COMPUTE_DRAWIN_STRUT(*drawin)
		}

#undef COMPUTE_DRAWIN_STRUT

	area.x += left;
	area.y += top;
	area.width -= MIN(area.width, left + right);
	area.height -= MIN(area.height, top + bottom);

	if (AREA_EQUAL(area, screen->workarea))
		return;

	area_t old_workarea = screen->workarea;
	screen->workarea = area;
	lua_State *L = globalconf_get_lua_State();
	luaA_object_push(L, screen);
	luaA_pusharea(L, old_workarea);
	luaA_object_emit_signal(L, -2, "property::workarea", 1);
	lua_pop(L, 1);
}

/** Apply all drawin struts for a monitor to a usable area
 * \param L Lua state
 * \param m Monitor to get drawins for
 * \param area Box to apply struts to (modified in place)
 *
 * This is called from arrangelayers() to ensure drawin struts (from Lua wibars)
 * are preserved when layer shell surfaces rearrange.
 */
void
luaA_monitor_apply_drawin_struts(lua_State *L, Monitor *m, struct wlr_box *area)
{
	screen_t *screen;

	if (!m || !area)
		return;

	/* Find the screen object for this monitor */
	screen = luaA_screen_get_by_monitor(L, m);
	if (!screen || !screen->valid)
		return;

	/* Apply the screen's cached workarea which already includes drawin struts
	 * The workarea is updated whenever drawin struts change via
	 * screen_update_workarea() */
	if (screen->workarea.width > 0 && screen->workarea.height > 0) {
		/* Only apply if the workarea is smaller than current area (has struts) */
		if (screen->workarea.y > area->y ||
		    screen->workarea.x > area->x ||
		    (screen->workarea.width < area->width) ||
		    (screen->workarea.height < area->height)) {
			*area = screen->workarea;
		}
	}
}

/* ========================================================================
 * Screen Lua API - property getters
 * ======================================================================== */

/** screen.geometry - Get screen geometry
 * \param screen Screen object
 * \return Table {x=, y=, width=, height=}
 */
static int
luaA_screen_get_geometry(lua_State *L)
{
	screen_t *screen = luaA_checkscreen(L, 1);

	if (!screen) {
		lua_newtable(L);
		return 1;
	}

	/* Return cached geometry */
	lua_newtable(L);
	lua_pushinteger(L, screen->geometry.x);
	lua_setfield(L, -2, "x");
	lua_pushinteger(L, screen->geometry.y);
	lua_setfield(L, -2, "y");
	lua_pushinteger(L, screen->geometry.width);
	lua_setfield(L, -2, "width");
	lua_pushinteger(L, screen->geometry.height);
	lua_setfield(L, -2, "height");

	return 1;
}

/** screen.workarea - Get screen workarea
 * \param screen Screen object
 * \return Table {x=, y=, width=, height=}
 */
static int
luaA_screen_get_workarea(lua_State *L)
{
	screen_t *screen = luaA_checkscreen(L, 1);

	if (!screen) {
		lua_newtable(L);
		return 1;
	}

	/* Return cached workarea */
	lua_newtable(L);
	lua_pushinteger(L, screen->workarea.x);
	lua_setfield(L, -2, "x");
	lua_pushinteger(L, screen->workarea.y);
	lua_setfield(L, -2, "y");
	lua_pushinteger(L, screen->workarea.width);
	lua_setfield(L, -2, "width");
	lua_pushinteger(L, screen->workarea.height);
	lua_setfield(L, -2, "height");

	return 1;
}

/** screen:get_bounding_geometry - Get screen bounding geometry
 * This method is used by awful.placement to detect screen objects.
 * Returns the full screen geometry (same as screen.geometry).
 * \param screen Screen object
 * \param args Optional args table (ignored for screens)
 * \return Table {x=, y=, width=, height=}
 */
static int
luaA_screen_get_bounding_geometry(lua_State *L)
{
	screen_t *screen;
	struct wlr_box geo;
	int honor_workarea, honor_padding;

	screen = luaA_checkscreen(L, 1);

	if (!screen) {
		lua_newtable(L);
		return 1;
	}

	/* Check for arguments table */
	honor_workarea = 0;
	honor_padding = 0;

	if (lua_istable(L, 2)) {
		lua_getfield(L, 2, "honor_workarea");
		honor_workarea = lua_toboolean(L, -1);
		lua_pop(L, 1);

		lua_getfield(L, 2, "honor_padding");
		honor_padding = lua_toboolean(L, -1);
		lua_pop(L, 1);
	}

	/* Use workarea if requested, otherwise full geometry */
	geo = honor_workarea ? screen->workarea : screen->geometry;

	/* TODO: Apply honor_padding and margins if needed */
	(void)honor_padding;

	lua_newtable(L);
	lua_pushinteger(L, geo.x);
	lua_setfield(L, -2, "x");
	lua_pushinteger(L, geo.y);
	lua_setfield(L, -2, "y");
	lua_pushinteger(L, geo.width);
	lua_setfield(L, -2, "width");
	lua_pushinteger(L, geo.height);
	lua_setfield(L, -2, "height");

	return 1;
}

/** screen.index - Get screen index
 * \param screen Screen object
 * \return Integer index (1-based)
 */
static int
luaA_screen_get_index(lua_State *L)
{
	screen_t *screen = luaA_checkscreen(L, 1);
	lua_pushinteger(L, screen ? screen->index : 0);
	return 1;
}

/** screen.outputs - Get output name
 * \param screen Screen object
 * \return Table with output name
 */
static int
luaA_screen_get_outputs(lua_State *L)
{
	screen_t *screen = luaA_checkscreen(L, 1);
	struct wlr_output *output;

	if (!screen || !screen->monitor || !screen->monitor->wlr_output) {
		lua_newtable(L);
		return 1;
	}

	output = screen->monitor->wlr_output;

	/* Create outputs table with numeric index (AwesomeWM format)
	 * Format: { [1] = { name=..., mm_width=..., mm_height=..., viewport_id=... } }
	 * The Lua layer (awful/screen.lua) converts this to name-keyed for user access */
	lua_newtable(L);

	/* Create output entry */
	lua_newtable(L);

	/* name */
	lua_pushstring(L, output->name);
	lua_setfield(L, -2, "name");

	/* mm_width - Physical width in millimeters (for DPI calculation) */
	lua_pushinteger(L, output->phys_width);
	lua_setfield(L, -2, "mm_width");

	/* mm_height - Physical height in millimeters (for DPI calculation) */
	lua_pushinteger(L, output->phys_height);
	lua_setfield(L, -2, "mm_height");

	/* viewport_id - Use screen index for AwesomeWM compatibility */
	lua_pushinteger(L, screen->index);
	lua_setfield(L, -2, "viewport_id");

	/* Set with numeric index 1 (AwesomeWM uses numeric indices) */
	lua_rawseti(L, -2, 1);

	return 1;
}

/** screen.name - Get screen name
 * \param screen Screen object
 * \return String name or monitor name if not set
 */
static int
luaA_screen_get_name(lua_State *L)
{
	screen_t *screen = luaA_checkscreen(L, 1);

	if (!screen) {
		lua_pushnil(L);
		return 1;
	}

	/* If user set a name, return that */
	if (screen->name) {
		lua_pushstring(L, screen->name);
	} else if (screen->monitor) {
		/* Otherwise return monitor name */
		const char *mon_name = some_get_monitor_name(screen->monitor);
		lua_pushstring(L, mon_name ? mon_name : "");
	} else {
		lua_pushliteral(L, "");
	}

	return 1;
}

/** screen.name (setter) - Set screen name
 * \param screen Screen object
 * \param name New name string
 */
static int
luaA_screen_set_name(lua_State *L, screen_t *screen)
{
	const char *new_name = luaL_checkstring(L, -1);
	const char *old_name = screen->name;

	/* Free old name if set */
	if (screen->name) {
		free(screen->name);
		screen->name = NULL;
	}

	/* Set new name */
	screen->name = strdup(new_name);

	/* Emit property::name signal if name actually changed */
	if ((old_name == NULL) ||
	    (old_name != NULL && strcmp(old_name, new_name) != 0)) {
		luaA_screen_push(L, screen);
		if (old_name) {
			lua_pushstring(L, old_name);
		} else {
			lua_pushnil(L);
		}
		luaA_object_emit_signal(L, -2, "property::name", 1);
		lua_pop(L, 1);  /* Pop screen object */
	}

	if (old_name)
		free((void*)old_name);

	return 0;
}

/** screen._managed - Get screen lifecycle management status
 * \param screen Screen object
 * \return String "C", "Lua", or "User"
 */
static int
luaA_screen_get_managed(lua_State *L)
{
	screen_t *screen = luaA_checkscreen(L, 1);

	if (!screen) {
		lua_pushnil(L);
		return 1;
	}

	/* Return lifecycle status */
	switch (screen->lifecycle) {
	case SCREEN_LIFECYCLE_C:
		lua_pushliteral(L, "C");
		break;
	case SCREEN_LIFECYCLE_LUA:
		lua_pushliteral(L, "Lua");
		break;
	case SCREEN_LIFECYCLE_USER:
		lua_pushliteral(L, "User");
		break;
	default:
		lua_pushliteral(L, "C");
		break;
	}

	return 1;
}

/* ========== SCREEN CONTENT (SCREENSHOT) SUPPORT ========== */

/** Callback data for scene buffer iteration during screenshot */
struct screen_screenshot_data {
	cairo_t *cr;
	struct wlr_renderer *renderer;
	int screen_x, screen_y;  /* Screen offset to subtract */
	int screen_w, screen_h;  /* Screen bounds */
};

/** Composite a Cairo surface onto the screenshot at the given position */
static void
screen_composite_cairo_surface(cairo_t *cr, cairo_surface_t *surface,
                               int x, int y, int width, int height)
{
	if (!surface || cairo_surface_status(surface) != CAIRO_STATUS_SUCCESS)
		return;

	cairo_save(cr);
	cairo_set_source_surface(cr, surface, x, y);
	cairo_set_operator(cr, CAIRO_OPERATOR_OVER);
	cairo_rectangle(cr, x, y, width, height);
	cairo_fill(cr);
	cairo_restore(cr);
}

/** Check if a box intersects with the screen bounds */
static bool
box_intersects_screen(int x, int y, int w, int h,
                      int sx, int sy, int sw, int sh)
{
	return !(x + w <= sx || x >= sx + sw || y + h <= sy || y >= sy + sh);
}

/** Composite a scene buffer to Cairo surface (for screen screenshot) */
static void
screen_composite_scene_buffer(struct wlr_scene_buffer *buffer,
                              int sx, int sy, void *data)
{
	struct screen_screenshot_data *sdata = data;
	struct wlr_buffer *wlr_buf;
	struct wlr_texture *texture;
	void *shm_data;
	uint32_t shm_format;
	size_t shm_stride;
	int rel_x, rel_y;
	size_t stride;
	void *pixels;

	if (!buffer->buffer)
		return;

	wlr_buf = buffer->buffer;

	/* Check if buffer intersects with screen */
	if (!box_intersects_screen(sx, sy, wlr_buf->width, wlr_buf->height,
	                           sdata->screen_x, sdata->screen_y,
	                           sdata->screen_w, sdata->screen_h))
		return;

	/* Offset position relative to screen origin */
	rel_x = sx - sdata->screen_x;
	rel_y = sy - sdata->screen_y;

	/* Try SHM buffer access first */
	if (wlr_buffer_begin_data_ptr_access(wlr_buf, WLR_BUFFER_DATA_PTR_ACCESS_READ,
	                                     &shm_data, &shm_format, &shm_stride)) {
		if (shm_format == DRM_FORMAT_ARGB8888 || shm_format == DRM_FORMAT_XRGB8888) {
			cairo_format_t fmt = (shm_format == DRM_FORMAT_ARGB8888) ?
			                     CAIRO_FORMAT_ARGB32 : CAIRO_FORMAT_RGB24;
			cairo_surface_t *tmp = cairo_image_surface_create_for_data(
				shm_data, fmt, wlr_buf->width, wlr_buf->height, shm_stride);
			if (cairo_surface_status(tmp) == CAIRO_STATUS_SUCCESS) {
				screen_composite_cairo_surface(sdata->cr, tmp,
				                               rel_x, rel_y,
				                               wlr_buf->width, wlr_buf->height);
			}
			cairo_surface_destroy(tmp);
		}
		wlr_buffer_end_data_ptr_access(wlr_buf);
		return;
	}

	/* Fall back to GPU texture path */
	texture = wlr_texture_from_buffer(sdata->renderer, wlr_buf);
	if (!texture)
		return;

	stride = wlr_buf->width * 4;
	pixels = malloc(stride * wlr_buf->height);
	if (!pixels) {
		wlr_texture_destroy(texture);
		return;
	}

	if (wlr_texture_read_pixels(texture, &(struct wlr_texture_read_pixels_options){
	    .data = pixels,
	    .format = DRM_FORMAT_ARGB8888,
	    .stride = stride,
	    .src_box = { .x = 0, .y = 0, .width = wlr_buf->width, .height = wlr_buf->height },
	})) {
		cairo_surface_t *tmp = cairo_image_surface_create_for_data(
			pixels, CAIRO_FORMAT_ARGB32, wlr_buf->width, wlr_buf->height, stride);
		if (cairo_surface_status(tmp) == CAIRO_STATUS_SUCCESS) {
			screen_composite_cairo_surface(sdata->cr, tmp,
			                               rel_x, rel_y,
			                               wlr_buf->width, wlr_buf->height);
		}
		cairo_surface_destroy(tmp);
	}

	free(pixels);
	wlr_texture_destroy(texture);
}

/** Composite widgets within the screen bounds, filtered by ontop state */
static void
screen_composite_widgets(cairo_t *cr, int sx, int sy, int sw, int sh, bool ontop_only)
{
	int i, bar;
	drawin_t *drawin;
	client_t *c;
	bool is_ontop;

	/* Composite visible drawins filtered by ontop state */
	for (i = 0; i < globalconf.drawins.len; i++) {
		drawin = globalconf.drawins.tab[i];
		if (!drawin || !drawin->visible || !drawin->drawable)
			continue;

		/* Filter by ontop to ensure correct z-order in screenshots */
		if (drawin->ontop != ontop_only)
			continue;

		if (!box_intersects_screen(drawin->x, drawin->y, drawin->width, drawin->height,
		                           sx, sy, sw, sh))
			continue;

		if (drawin->drawable->surface &&
		    cairo_surface_status(drawin->drawable->surface) == CAIRO_STATUS_SUCCESS) {
			screen_composite_cairo_surface(cr, drawin->drawable->surface,
			                               drawin->x - sx, drawin->y - sy,
			                               drawin->width, drawin->height);
		}
	}

	/* Composite client titlebars filtered by ontop/fullscreen state */
	for (i = 0; i < globalconf.clients.len; i++) {
		c = globalconf.clients.tab[i];
		if (!c)
			continue;

		/* Filter by ontop/fullscreen to ensure correct z-order */
		is_ontop = c->ontop || c->fullscreen;
		if (is_ontop != ontop_only)
			continue;

		for (bar = 0; bar < CLIENT_TITLEBAR_COUNT; bar++) {
			drawable_t *d = c->titlebar[bar].drawable;
			int size = c->titlebar[bar].size;
			int tb_x, tb_y, tb_w, tb_h;

			if (!d || !d->surface || size <= 0)
				continue;

			/* Calculate titlebar position */
			switch (bar) {
			case CLIENT_TITLEBAR_TOP:
				tb_x = c->geometry.x;
				tb_y = c->geometry.y;
				tb_w = c->geometry.width;
				tb_h = size;
				break;
			case CLIENT_TITLEBAR_BOTTOM:
				tb_x = c->geometry.x;
				tb_y = c->geometry.y + c->geometry.height - size;
				tb_w = c->geometry.width;
				tb_h = size;
				break;
			case CLIENT_TITLEBAR_LEFT:
				tb_x = c->geometry.x;
				tb_y = c->geometry.y + c->titlebar[CLIENT_TITLEBAR_TOP].size;
				tb_w = size;
				tb_h = c->geometry.height - c->titlebar[CLIENT_TITLEBAR_TOP].size
				       - c->titlebar[CLIENT_TITLEBAR_BOTTOM].size;
				break;
			case CLIENT_TITLEBAR_RIGHT:
				tb_x = c->geometry.x + c->geometry.width - size;
				tb_y = c->geometry.y + c->titlebar[CLIENT_TITLEBAR_TOP].size;
				tb_w = size;
				tb_h = c->geometry.height - c->titlebar[CLIENT_TITLEBAR_TOP].size
				       - c->titlebar[CLIENT_TITLEBAR_BOTTOM].size;
				break;
			default:
				continue;
			}

			if (!box_intersects_screen(tb_x, tb_y, tb_w, tb_h, sx, sy, sw, sh))
				continue;

			screen_composite_cairo_surface(cr, d->surface,
			                               tb_x - sx, tb_y - sy,
			                               tb_w, tb_h);
		}
	}
}

/** Get screenshot of this screen
 * \param L Lua state
 * \param s Screen object
 * \return 1 (cairo surface lightuserdata on stack)
 */
static int
luaA_screen_get_content(lua_State *L, screen_t *s)
{
	cairo_surface_t *surface;
	cairo_t *cr;
	struct screen_screenshot_data sdata;
	int width, height;

	if (!s || !s->valid)
		return 0;

	width = s->geometry.width;
	height = s->geometry.height;

	if (width <= 0 || height <= 0)
		return 0;

	/* Create Cairo surface for this screen */
	surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, width, height);
	if (cairo_surface_status(surface) != CAIRO_STATUS_SUCCESS)
		return 0;

	cr = cairo_create(surface);

	/* Clear to black */
	cairo_set_source_rgb(cr, 0, 0, 0);
	cairo_paint(cr);

	/* Set up screenshot data */
	sdata.cr = cr;
	sdata.renderer = drw;
	sdata.screen_x = s->geometry.x;
	sdata.screen_y = s->geometry.y;
	sdata.screen_w = width;
	sdata.screen_h = height;

	/* First, composite wallpaper (cropped to screen area) */
	if (globalconf.wallpaper) {
		screen_composite_cairo_surface(cr, globalconf.wallpaper,
		                               -s->geometry.x, -s->geometry.y,
		                               cairo_image_surface_get_width(globalconf.wallpaper),
		                               cairo_image_surface_get_height(globalconf.wallpaper));
	}

	/* Then iterate scene buffers for client content */
	wlr_scene_node_for_each_buffer(&scene->tree.node,
		screen_composite_scene_buffer, &sdata);

	/* Composite widgets in z-order: normal first, then ontop */
	screen_composite_widgets(cr, s->geometry.x, s->geometry.y, width, height, false);
	screen_composite_widgets(cr, s->geometry.x, s->geometry.y, width, height, true);

	cairo_destroy(cr);

	/* Return surface as lightuserdata */
	lua_pushlightuserdata(L, surface);
	return 1;
}

/* ========== END SCREEN CONTENT SUPPORT ========== */

/* Property wrappers for luaA_class_add_property - these adapt the existing
 * getter functions to the property system's (lua_State*, screen_t*) signature */

static int luaA_screen_get_geometry_prop(lua_State *L, screen_t *s) {
	(void)s;  /* screen is on stack at position 1 */
	return luaA_screen_get_geometry(L);
}

static int luaA_screen_get_index_prop(lua_State *L, screen_t *s) {
	(void)s;
	return luaA_screen_get_index(L);
}

static int luaA_screen_get_outputs_prop(lua_State *L, screen_t *s) {
	(void)s;
	return luaA_screen_get_outputs(L);
}

static int luaA_screen_get_workarea_prop(lua_State *L, screen_t *s) {
	(void)s;
	return luaA_screen_get_workarea(L);
}

static int luaA_screen_get_name_prop(lua_State *L, screen_t *s) {
	(void)s;
	return luaA_screen_get_name(L);
}

static int luaA_screen_get_managed_prop(lua_State *L, screen_t *s) {
	(void)s;
	return luaA_screen_get_managed(L);
}

/** Get current output scale for this screen.
 * \param L The Lua state.
 * \param s The screen object.
 * \return Number of values pushed on stack (1).
 */
static int luaA_screen_get_scale(lua_State *L, screen_t *s)
{
	if (s && s->monitor && s->monitor->wlr_output) {
		lua_pushnumber(L, s->monitor->wlr_output->scale);
	} else {
		lua_pushnumber(L, 1.0);
	}
	return 1;
}

/** Set output scale for this screen.
 * Delegates to output.scale — one source of truth.
 * output.scale setter handles wlr_output commit and emits property::scale
 * on both the output and this screen for backward compatibility.
 *
 * \param L The Lua state.
 * \param s The screen object.
 * \return Number of values pushed on stack (0).
 */
static int luaA_screen_set_scale(lua_State *L, screen_t *s)
{
	float scale = luaL_checknumber(L, -1);

	if (scale < 0.1 || scale > 10.0) {
		luaL_error(L, "scale must be between 0.1 and 10.0, got %f", scale);
		return 0;
	}

	if (!s || !s->monitor || !s->monitor->output)
		return 0;

	/* Delegate to output — emits property::scale on both objects */
	luaA_object_push(L, s->monitor->output);
	luaA_output_apply_scale(L, s->monitor->output, -1, scale);
	lua_pop(L, 1);
	return 0;
}

/** Get the output object for this screen.
 * For real screens backed by a physical monitor, returns the monitor's output.
 * For fake screens (from screen.fake_add), returns the synthetic virtual output.
 * \param L The Lua state.
 * \param s The screen object.
 * \return Number of values pushed on stack (1).
 */
static int luaA_screen_get_output(lua_State *L, screen_t *s)
{
	if (s && s->monitor && s->monitor->output)
		luaA_object_push(L, s->monitor->output);
	else if (s && s->virtual_output)
		luaA_object_push(L, s->virtual_output);
	else
		lua_pushnil(L);
	return 1;
}

/* ========================================================================
 * Screen Lua API - global functions
 * ======================================================================== */

/** screen.count() - Get number of screens
 * \return Integer count
 */
static int
luaA_screen_count(lua_State *L)
{
	lua_pushinteger(L, screen_count);
	return 1;
}

/** screen._viewports() - Get viewport information for all monitors
 * Returns viewport data used for DPI calculation by awful.screen.dpi
 *
 * \return Table of viewport tables with format:
 * {
 *   [1] = {
 *     geometry = {x=0, y=0, width=1920, height=1080},
 *     outputs = {
 *       [1] = {mm_width=530, mm_height=300, name="HDMI-A-1", viewport_id=1}
 *     },
 *     id = 1
 *   }
 * }
 */
static int
luaA_screen_viewports(lua_State *L)
{
	Monitor *m;
	int viewport_id = 1;

	lua_newtable(L);  /* Create main viewport array */

	wl_list_for_each(m, &mons, link) {
		if (!m->wlr_output)
			continue;

		lua_newtable(L);  /* Create viewport table */

		/* Add geometry table */
		lua_pushliteral(L, "geometry");
		lua_newtable(L);
		lua_pushinteger(L, m->m.x);
		lua_setfield(L, -2, "x");
		lua_pushinteger(L, m->m.y);
		lua_setfield(L, -2, "y");
		lua_pushinteger(L, m->m.width);
		lua_setfield(L, -2, "width");
		lua_pushinteger(L, m->m.height);
		lua_setfield(L, -2, "height");
		lua_settable(L, -3);  /* Set geometry in viewport table */

		/* Add outputs array */
		lua_pushliteral(L, "outputs");
		lua_newtable(L);  /* Create outputs array */

		/* Create first output entry */
		lua_newtable(L);
		lua_pushinteger(L, m->wlr_output->phys_width);
		lua_setfield(L, -2, "mm_width");
		lua_pushinteger(L, m->wlr_output->phys_height);
		lua_setfield(L, -2, "mm_height");
		lua_pushstring(L, m->wlr_output->name);
		lua_setfield(L, -2, "name");
		lua_pushinteger(L, viewport_id);
		lua_setfield(L, -2, "viewport_id");
		lua_rawseti(L, -2, 1);  /* outputs[1] = output_table */

		lua_settable(L, -3);  /* Set outputs in viewport table */

		/* Add viewport ID */
		lua_pushliteral(L, "id");
		lua_pushinteger(L, viewport_id);
		lua_settable(L, -3);  /* Set id in viewport table */

		/* Add viewport to main array */
		lua_rawseti(L, -2, viewport_id);
		viewport_id++;
	}

	return 1;
}

/** screen.fake_add(x, y, width, height) - Create virtual screen (AwesomeWM API)
 * Used by awful.screen.split() to divide physical monitors into virtual screens.
 * \param x X position
 * \param y Y position
 * \param width Width
 * \param height Height
 * \return New screen object
 */
static int
luaA_screen_fake_add(lua_State *L)
{
	int x = luaL_checkinteger(L, 1);
	int y = luaL_checkinteger(L, 2);
	int width = luaL_checkinteger(L, 3);
	int height = luaL_checkinteger(L, 4);
	screen_t *screen;
	int ref;

	/* Allocate screen userdata */
	screen = (screen_t *)lua_newuserdata(L, sizeof(screen_t));
	if (!screen) {
		return luaL_error(L, "Failed to allocate virtual screen");
	}

	/* Initialize virtual screen (no monitor) */
	screen->monitor = NULL;  /* Virtual screen has no physical monitor */
	screen->index = (int)(screen_count + 1);
	screen->valid = true;
	screen->lifecycle = SCREEN_LIFECYCLE_USER;
	screen->geometry.x = x;
	screen->geometry.y = y;
	screen->geometry.width = width;
	screen->geometry.height = height;
	screen->workarea = screen->geometry;
	screen->name = NULL;
	screen->virtual_output = NULL;
	signal_array_init(&screen->signals);

	/* Set metatable using class-based lookup (not named metatable) */
	lua_pushlightuserdata(L, &screen_class);
	lua_rawget(L, LUA_REGISTRYINDEX);
	lua_setmetatable(L, -2);

	/* Initialize environment table (must match LUA_OBJECT_FUNCS pattern:
	 * env table + metatable for refcounting + "data" sub-table) */
	lua_newtable(L);
	lua_newtable(L);
	lua_setmetatable(L, -2);
	lua_newtable(L);
	lua_setfield(L, -2, "data");
	luaA_setuservalue(L, -2);

	/* Store reference in registry */
	lua_pushvalue(L, -1);
	ref = luaL_ref(L, LUA_REGISTRYINDEX);

	/* Register in object registry so luaA_object_push() can find it.
	 * Without this, screen_added() → luaA_object_push() → returns nil,
	 * and the "_added" signal is never emitted (matching luaA_screen_new). */
	lua_pushvalue(L, -1);
	luaA_object_ref(L, -1);

	/* Add to screen array */
	if (screen_count >= screen_capacity) {
		size_t new_cap = screen_capacity == 0 ? 4 : screen_capacity * 2;
		int *new_refs = realloc(screen_refs, new_cap * sizeof(int));
		if (!new_refs) {
			luaL_unref(L, LUA_REGISTRYINDEX, ref);
			return luaL_error(L, "Failed to allocate screen array");
		}
		screen_refs = new_refs;
		screen_capacity = new_cap;
	}
	screen_refs[screen_count++] = ref;

	/* Create synthetic virtual output so screen.output is never nil */
	screen->virtual_output = luaA_output_new_virtual(L, NULL);
	if (screen->virtual_output)
		lua_pop(L, 1);  /* Pop userdata (tracked in output.c) */

	/* Emit "added" signal */
	screen_added(L, screen);

	/* Emit class-level "list" signal */
	luaA_class_emit_signal(L, &screen_class, "list", 0);

	/* Emit output "added" signal for the virtual output */
	if (screen->virtual_output) {
		luaA_object_push(L, screen->virtual_output);
		luaA_class_emit_signal(L, &output_class, "added", 1);
	}

	/* Relocate clients that should now be on this new screen (AwesomeWM behavior) */
	foreach(c, globalconf.clients) {
		int cx = (*c)->geometry.x + (*c)->geometry.width / 2;
		int cy = (*c)->geometry.y + (*c)->geometry.height / 2;
		screen_t *best = luaA_screen_getbycoord(L, cx, cy);
		if (best && best != (*c)->screen) {
			screen_client_moveto(*c, best, false);
		}
	}

	/* Return screen object (still on stack) */
	return 1;
}

/** screen:fake_remove() - Remove virtual screen (AwesomeWM API)
 * Removes a screen created by fake_add()
 */
static int
luaA_screen_fake_remove(lua_State *L)
{
	screen_t *screen = luaA_checkscreen(L, 1);

	if (!screen || !screen->valid) {
		return 0;
	}

	/* Clean up virtual output if present */
	if (screen->virtual_output) {
		luaA_object_push(L, screen->virtual_output);
		luaA_class_emit_signal(L, &output_class, "removed", 1);
		luaA_output_invalidate(L, screen->virtual_output);
		screen->virtual_output = NULL;
	}

	/* Use shared removal logic (emits signals, moves clients, etc.) */
	screen_removed(L, screen);

	return 0;
}

/** screen:fake_resize(x, y, width, height) - Resize virtual screen (AwesomeWM API)
 * Changes the geometry of a virtual screen
 */
static int
luaA_screen_fake_resize(lua_State *L)
{
	screen_t *screen = luaA_checkscreen(L, 1);
	int x = luaL_checkinteger(L, 2);
	int y = luaL_checkinteger(L, 3);
	int width = luaL_checkinteger(L, 4);
	int height = luaL_checkinteger(L, 5);
	struct wlr_box old_geometry;

	if (!screen || !screen->valid) {
		return 0;
	}

	/* Save old geometry for signal */
	old_geometry = screen->geometry;

	/* Update geometry */
	screen->geometry.x = x;
	screen->geometry.y = y;
	screen->geometry.width = width;
	screen->geometry.height = height;

	/* Update workarea properly (accounts for struts from wibars)
	 * This will use geometry as baseline and emit property::workarea if needed */
	screen_update_workarea(screen);

	/* Emit property::geometry signal with old value */
	luaA_screen_push(L, screen);
	push_wlr_box(L, &old_geometry);
	luaA_object_emit_signal(L, -2, "property::geometry", 1);
	lua_pop(L, 1);

	return 0;
}

/** Swap two screens in the screen list.
 *
 * @method swap
 * @tparam screen other_screen The screen to swap with.
 * @noreturn
 */
static int
luaA_screen_swap(lua_State *L)
{
	screen_t *s = luaA_checkscreen(L, 1);
	screen_t *swap = luaA_checkscreen(L, 2);

	if (!s || !swap || !s->valid || !swap->valid)
		return 0;

	if (s != swap) {
		int ref_s_idx = -1, ref_swap_idx = -1;
		int tmp_ref;
		size_t i;

		/* Find indices of both screens */
		for (i = 0; i < screen_count; i++) {
			screen_t *screen = NULL;
			lua_rawgeti(L, LUA_REGISTRYINDEX, screen_refs[i]);
			screen = luaA_checkscreen(L, -1);
			lua_pop(L, 1);

			if (screen == s)
				ref_s_idx = i;
			else if (screen == swap)
				ref_swap_idx = i;

			if (ref_s_idx >= 0 && ref_swap_idx >= 0)
				break;
		}

		if (ref_s_idx < 0 || ref_swap_idx < 0)
			return luaL_error(L, "Invalid call to screen:swap()");

		/* Swap the refs */
		tmp_ref = screen_refs[ref_s_idx];
		screen_refs[ref_s_idx] = screen_refs[ref_swap_idx];
		screen_refs[ref_swap_idx] = tmp_ref;

		/* Update indices */
		s->index = ref_swap_idx + 1;
		swap->index = ref_s_idx + 1;

		/* Emit screen.list class signal */
		luaA_class_emit_signal(L, &screen_class, "list", 0);

		/* Emit swapped signal on first screen */
		luaA_screen_push(L, swap);
		lua_pushboolean(L, true);
		luaA_screen_push(L, s);
		luaA_object_emit_signal(L, -3, "swapped", 2);
		lua_pop(L, 1);

		/* Emit swapped signal on second screen */
		luaA_screen_push(L, s);
		lua_pushboolean(L, false);
		luaA_screen_push(L, swap);
		luaA_object_emit_signal(L, -3, "swapped", 2);
		lua_pop(L, 1);
	}

	return 0;
}

/** screen[index] or screen(index) - Get screen by index
 * \param index Screen index (1-based)
 * \return Screen object or nil
 */
static int
luaA_screen_get_by_index(lua_State *L)
{
	int index = luaL_checkinteger(L, 1);

	if (index < 1 || index > (int)screen_count) {
		lua_pushnil(L);
		return 1;
	}

	/* Push screen from registry */
	lua_rawgeti(L, LUA_REGISTRYINDEX, screen_refs[index - 1]);
	return 1;
}

/** __index metamethod for screen class table
 * Handles:
 * - screen[1] -> screen object (numeric index)
 * - screen[screen_obj] -> screen_obj (identity for screen objects)
 * - screen.method_name -> method (method lookup)
 */
static int
luaA_screen_module_index(lua_State *L)
{
	/* L[1] is the screen table, L[2] is the key */

	/* Numeric index: screen[1] */
	if (lua_isnumber(L, 2)) {
		int index = lua_tointeger(L, 2);

		if (index < 1 || index > (int)screen_count) {
			lua_pushnil(L);
			return 1;
		}

		/* Push screen from registry */
		lua_rawgeti(L, LUA_REGISTRYINDEX, screen_refs[index - 1]);
		return 1;
	}

	/* Screen object as key: screen[screen_obj] -> screen_obj
	 * This allows get_screen() functions to work: get_screen(s) where s might
	 * already be a screen object. Calling screen[s] returns s unchanged.
	 */
	if (lua_isuserdata(L, 2)) {
		screen_t *s = luaA_checkscreen(L, 2);
		if (s && s->valid) {
			/* Return the same screen object */
			lua_pushvalue(L, 2);
			return 1;
		}
		/* Invalid screen, return nil */
		lua_pushnil(L);
		return 1;
	}

	/* Special handling for .primary and .automatic_factory properties (AwesomeWM compatibility) */
	if (lua_isstring(L, 2)) {
		const char *key = lua_tostring(L, 2);
		if (strcmp(key, "automatic_factory") == 0) {
			/* Always return true - we automatically manage screens */
			lua_pushboolean(L, 1);
			return 1;
		} else if (strcmp(key, "primary") == 0) {
			screen_t *primary;

			primary = luaA_screen_get_primary_screen(L);
			if (primary) {
				luaA_object_push(L, primary);
			} else {
				lua_pushnil(L);
			}
			return 1;
		}
	}

	/* Method/property lookup: screen.method_name */
	lua_pushvalue(L, 2);  /* Push key */
	lua_rawget(L, 1);     /* Get screen_table[key] */

	return 1;
}

/** __call metamethod for screen class
 * This function serves as both:
 * 1. The iterator function for "for s in screen do" loops
 * 2. Direct indexing via screen(index)
 *
 * For iteration, the generic for loop calls this as: screen(nil, previous_screen)
 * where previous_screen is nil on first iteration, then each subsequent screen.
 * We return the next screen in the sequence, or nil when done.
 *
 * This matches AwesomeWM's implementation pattern.
 */
static int
luaA_screen_call(lua_State *L)
{
	int index;
	screen_t *prev;


	/* For iteration: screen(state, control_var) where L[1]=self, L[2]=state, L[3]=control_var
	 * For direct call: screen(index) where L[1]=self, L[2]=index */

	/* Check if this is direct indexing: screen(number) */
	if (lua_gettop(L) >= 2 && lua_isnumber(L, 2) && !lua_isnil(L, 2)) {
		index = luaL_checkinteger(L, 2);

		if (index < 1 || index > (int)screen_count) {
			lua_pushnil(L);
			return 1;
		}

		lua_rawgeti(L, LUA_REGISTRYINDEX, screen_refs[index - 1]);
		return 1;
	}

	/* Iterator mode: L[3] is the control variable (previous screen or nil) */
	if (lua_isnoneornil(L, 3)) {
		/* First iteration - return first screen */
		index = 0;
	} else {
		/* Get previous screen and return next one */
		prev = luaA_toscreen(L, 3);
		if (!prev) {
			lua_pushnil(L);
			return 1;
		}
		index = prev->index;
	}

	/* Return next screen */
	if (index >= 0 && index < (int)screen_count) {
		screen_t *s;

		/* Get screen pointer from registry to use with luaA_object_push */
		lua_rawgeti(L, LUA_REGISTRYINDEX, screen_refs[index]);
		s = luaA_toscreen(L, -1);
		lua_pop(L, 1);  /* Pop the userdata we just retrieved */

		if (s) {
			/* Use AwesomeWM's object push for proper metatable */
			luaA_object_push(L, s);
		} else {
			lua_pushnil(L);
		}
		return 1;
	}

	/* No more screens */
	lua_pushnil(L);
	return 1;
}

/* ========================================================================
 * Screen Lua API - object methods (metamethods)
 * ======================================================================== */

/** screen:connect_signal(name, callback) - Connect to a screen signal
 */
static int
luaA_screen_connect_signal(lua_State *L)
{
	/* Use common infrastructure instead of custom signal code */
	return luaA_object_connect_signal_simple(L);
}

static int
luaA_screen_emit_signal(lua_State *L)
{
	return luaA_object_emit_signal_simple(L);
}

/** screen:disconnect_signal(name, callback) - Disconnect from a screen signal
 * Matches connect_signal which delegates to luaA_object_connect_signal_simple.
 */
static int
luaA_screen_disconnect_signal(lua_State *L)
{
	return luaA_object_disconnect_signal_simple(L);
}

/** screen:__index - Property getter
 */
static int
luaA_screen_index(lua_State *L)
{
	const char *key;

	/* Validate screen object (luaA_checkscreen will error if invalid) */
	screen_t *s = luaA_checkscreen(L, 1);
	(void)s;  /* Used for validation */
	key = luaL_checkstring(L, 2);

	/* Check for properties */
	if (strcmp(key, "geometry") == 0)
		return luaA_screen_get_geometry(L);
	if (strcmp(key, "workarea") == 0)
		return luaA_screen_get_workarea(L);
	if (strcmp(key, "index") == 0)
		return luaA_screen_get_index(L);
	if (strcmp(key, "outputs") == 0)
		return luaA_screen_get_outputs(L);
	if (strcmp(key, "name") == 0)
		return luaA_screen_get_name(L);
	if (strcmp(key, "_managed") == 0)
		return luaA_screen_get_managed(L);
	if (strcmp(key, "valid") == 0) {
		screen_t *screen = luaA_checkscreen(L, 1);
		lua_pushboolean(L, screen->valid);
		return 1;
	}
	if (strcmp(key, "scale") == 0) {
		screen_t *screen = luaA_checkscreen(L, 1);
		return luaA_screen_get_scale(L, screen);
	}
	if (strcmp(key, "output") == 0) {
		screen_t *screen = luaA_checkscreen(L, 1);
		return luaA_screen_get_output(L, screen);
	}

	/* Check for _private table (AwesomeWM compatibility) */
	if (strcmp(key, "_private") == 0) {
		luaA_getuservalue(L, 1);  /* Return the environment table itself */
		return 1;
	}

	/* Check for methods in metatable */
	lua_getmetatable(L, 1);  /* Get the actual metatable of the screen object */
	if (!lua_isnil(L, -1)) {
		lua_getfield(L, -1, key);
		if (!lua_isnil(L, -1)) {
			return 1;  /* Found in metatable */
		}
		lua_pop(L, 1);  /* Pop nil result */
	}
	lua_pop(L, 1);  /* Pop metatable (or nil if no metatable) */

	/* Call index miss handler if registered (for dynamic properties) */
	if (screen_class.index_miss_handler != LUA_REFNIL) {
		lua_rawgeti(L, LUA_REGISTRYINDEX, screen_class.index_miss_handler);
		lua_pushvalue(L, 1);  /* Push screen object */
		lua_pushvalue(L, 2);  /* Push key */
		lua_call(L, 2, 1);    /* Call handler(screen, key) */
		return 1;
	}

	/* Fallback: check for custom properties in environment table */
	luaA_getuservalue(L, 1);
	lua_getfield(L, -1, key);
	return 1;
}

/** screen:__newindex - Property setter
 */
static int
luaA_screen_newindex(lua_State *L)
{
	screen_t *screen = luaA_checkscreen(L, 1);
	const char *key = luaL_checkstring(L, 2);

	/* Only 'name' property is writable */
	if (strcmp(key, "name") == 0) {
		const char *new_name = NULL;
		char *old_name = screen->name ? strdup(screen->name) : NULL;

		/* Get new name (can be nil to unset) */
		if (!lua_isnil(L, 3)) {
			new_name = luaL_checkstring(L, 3);
		}

		/* Free old name if set */
		if (screen->name) {
			free(screen->name);
			screen->name = NULL;
		}

		/* Set new name if provided */
		if (new_name) {
			screen->name = strdup(new_name);
		}

		/* Emit property::name signal if name actually changed */
		if ((old_name == NULL && new_name != NULL) ||
		    (old_name != NULL && new_name == NULL) ||
		    (old_name != NULL && new_name != NULL && strcmp(old_name, new_name) != 0)) {
			luaA_screen_push(L, screen);
			if (old_name) {
				lua_pushstring(L, old_name);
			} else {
				lua_pushnil(L);
			}
			luaA_object_emit_signal(L, -2, "property::name", 1);
			lua_pop(L, 1);  /* Pop screen object */
		}
		free(old_name);

		return 0;
	}

	/* Handle scale property */
	if (strcmp(key, "scale") == 0) {
		lua_pushvalue(L, 3);  /* Push value to top where setter expects it */
		luaA_screen_set_scale(L, screen);
		lua_pop(L, 1);
		return 0;
	}

	/* Call newindex miss handler if registered (for dynamic properties) */
	if (screen_class.newindex_miss_handler != LUA_REFNIL) {
		lua_rawgeti(L, LUA_REGISTRYINDEX, screen_class.newindex_miss_handler);
		lua_pushvalue(L, 1);  /* Push screen object */
		lua_pushvalue(L, 2);  /* Push key */
		lua_pushvalue(L, 3);  /* Push value */
		lua_call(L, 3, 0);    /* Call handler(screen, key, value) */
		return 0;
	}

	/* Fallback: Allow arbitrary properties to be stored in the userdata
	 * environment table. This allows Lua code to attach custom properties
	 * like mywibox, mytaglist, etc. to screen objects.
	 */
	luaA_getuservalue(L, 1);
	lua_pushvalue(L, 2);  /* Push key */
	lua_pushvalue(L, 3);  /* Push value */
	lua_rawset(L, -3);    /* env[key] = value */
	lua_pop(L, 1);        /* Pop environment table */

	return 0;
}

/** screen:__tostring - Convert to string
 */
static int
luaA_screen_tostring(lua_State *L)
{
	screen_t *screen = luaA_checkscreen(L, 1);
	const char *name = screen && screen->monitor ? some_get_monitor_name(screen->monitor) : "unknown";
	lua_pushfstring(L, "screen{index=%d, name=%s}", screen ? screen->index : 0, name ? name : "nil");
	return 1;
}

/** screen:__gc - Garbage collector
 */
static int
luaA_screen_gc(lua_State *L)
{
	screen_t *screen = luaA_toscreen(L, 1);
	if (screen) {
		screen->valid = false;
		signal_array_wipe(&screen->signals);
		/* Free name if allocated */
		if (screen->name) {
			free(screen->name);
			screen->name = NULL;
		}
	}
	return 0;
}

/* ========================================================================
 * Screen class-level signal methods
 * ======================================================================== */

/* Note: LUA_CLASS_FUNCS macro (line 14) automatically generates these functions:
 * - luaA_screen_class_add_signal (deprecated, no-op)
 * - luaA_screen_class_connect_signal
 * - luaA_screen_class_disconnect_signal
 * - luaA_screen_class_emit_signal
 * - luaA_screen_set_index_miss_handler
 * - luaA_screen_set_newindex_miss_handler
 * - luaA_screen_get_index_miss_handler
 * - luaA_screen_get_newindex_miss_handler
 */

/* ========================================================================
 * Screen-client operations (AwesomeWM compatibility)
 * ======================================================================== */

/** Get screen at coordinates - X11 compatibility wrapper
 * \param x The x coordinate
 * \param y The y coordinate
 * \return The screen at the given coordinates, or nearest screen if outside all screens
 */
screen_t *
screen_getbycoord(int x, int y)
{
	lua_State *L = globalconf_get_lua_State();
	return luaA_screen_getbycoord(L, x, y);
}

/** Check if a geometry overlaps with a screen
 * \param s The screen
 * \param geom The geometry
 * \return True if there is any overlap between the geometry and the screen
 */
bool
screen_area_in_screen(screen_t *s, area_t geom)
{
	return (geom.x < s->geometry.x + s->geometry.width)
	       && (geom.x + geom.width > s->geometry.x)
	       && (geom.y < s->geometry.y + s->geometry.height)
	       && (geom.y + geom.height > s->geometry.y);
}

/** Get the Monitor (wlroots output wrapper) for a given screen object
 * \param L The Lua state
 * \param screen The screen object to find the monitor for
 * \return The Monitor associated with the screen, or NULL if not found
 */
Monitor *
luaA_monitor_get_by_screen(lua_State *L, screen_t *screen)
{
	extern struct wl_list mons;
	Monitor *m;

	if (!screen)
		return NULL;

	wl_list_for_each(m, &mons, link) {
		if (luaA_screen_get_by_monitor(L, m) == screen)
			return m;
	}
	return NULL;
}

/** Move a client to a screen (AwesomeWM pattern)
 * \param c The client to move
 * \param new_screen The destination screen
 * \param doresize True to resize/reposition the client for the new screen
 */
void
screen_client_moveto(client_t *c, screen_t *new_screen, bool doresize)
{
	lua_State *L = globalconf_get_lua_State();
	screen_t *old_screen = c->screen;
	area_t from, to;
	area_t new_geometry;
	bool had_focus = false;

	/* Forward declare apply_geometry_to_wlroots from somewm.c */
	extern void apply_geometry_to_wlroots(client_t *c);

	if (new_screen == c->screen)
		return;

	if (globalconf.focus.client == c)
		had_focus = true;

	c->screen = new_screen;

	/* Update c->mon to match the new screen (fixes multi-monitor visibility bug) */
	if (new_screen) {
		Monitor *new_mon = luaA_monitor_get_by_screen(L, new_screen);
		if (new_mon && new_mon != c->mon) {
			extern void banning_need_update(void);
			c->mon = new_mon;
			banning_need_update();
		}
	}

	if (!doresize) {
		luaA_object_push(L, c);
		if (old_screen != NULL)
			luaA_object_push(L, old_screen);
		else
			lua_pushnil(L);
		luaA_object_emit_signal(L, -2, "property::screen", 1);
		lua_pop(L, 1);
		if (had_focus)
			client_focus(c);
		return;
	}

	/* If new_screen is NULL, skip resize logic - can't position relative to nothing */
	if (!new_screen) {
		luaA_object_push(L, c);
		if (old_screen != NULL)
			luaA_object_push(L, old_screen);
		else
			lua_pushnil(L);
		luaA_object_emit_signal(L, -2, "property::screen", 1);
		lua_pop(L, 1);
		if (had_focus)
			client_focus(c);
		return;
	}

	if (old_screen)
		from = old_screen->geometry;
	else
		from = new_screen->geometry;  /* No old screen, use new screen geometry */
	to = new_screen->geometry;

	new_geometry = c->geometry;

	new_geometry.x = to.x + new_geometry.x - from.x;
	new_geometry.y = to.y + new_geometry.y - from.y;

	/* resize the client if it doesn't fit the new screen */
	if (new_geometry.width > to.width)
		new_geometry.width = to.width;
	if (new_geometry.height > to.height)
		new_geometry.height = to.height;

	/* make sure the client is still on the screen */
	if (new_geometry.x + new_geometry.width > to.x + to.width)
		new_geometry.x = to.x + to.width - new_geometry.width;
	if (new_geometry.y + new_geometry.height > to.y + to.height)
		new_geometry.y = to.y + to.height - new_geometry.height;
	if (!screen_area_in_screen(new_screen, new_geometry)) {
		/* If all else fails, force the client to end up on screen. */
		new_geometry.x = to.x;
		new_geometry.y = to.y;
	}

	/* move / resize the client */
	client_resize(c, new_geometry, false, false);

	/* Force immediate scene node position update (bypass deferred refresh)
	 * This ensures the window appears on the new screen immediately */
	apply_geometry_to_wlroots(c);

	/* emit signal */
	luaA_object_push(L, c);
	if (old_screen != NULL)
		luaA_object_push(L, old_screen);
	else
		lua_pushnil(L);
	luaA_object_emit_signal(L, -2, "property::screen", 1);
	lua_pop(L, 1);

	if (had_focus)
		client_focus(c);
}

/* ========================================================================
 * Screen class setup
 * ======================================================================== */

/* Screen instance metamethods (AwesomeWM pattern) */
const luaL_Reg screen_meta[] = {
	/* Basic metamethods */
	{ "__index", luaA_screen_index },
	{ "__newindex", luaA_screen_newindex },
	{ "__tostring", luaA_screen_tostring },
	{ "__gc", luaA_screen_gc },
	/* Signal support */
	{ "connect_signal", luaA_screen_connect_signal },
	{ "disconnect_signal", luaA_screen_disconnect_signal },
	{ "emit_signal", luaA_screen_emit_signal },
	/* Screen-specific methods */
	{ "get_bounding_geometry", luaA_screen_get_bounding_geometry },
	{ "fake_remove", luaA_screen_fake_remove },
	{ "fake_resize", luaA_screen_fake_resize },
	{ "swap", luaA_screen_swap },
	{ NULL, NULL }
};

/** Check if a screen is valid (AwesomeWM pattern) */
static bool
screen_checker(screen_t *s)
{
	(void)s;
	/* In somewm, screens are always valid once created
	 * TODO: Implement proper validation if needed */
	return true;
}

/* Screen class methods (for global screen table) */
const luaL_Reg screen_methods[] = {
	/* Class-level signal methods (generated by LUA_CLASS_FUNCS) */
	{ "add_signal", luaA_screen_class_add_signal },
	{ "connect_signal", luaA_screen_class_connect_signal },
	{ "disconnect_signal", luaA_screen_class_disconnect_signal },
	{ "emit_signal", luaA_screen_class_emit_signal },
	{ "set_index_miss_handler", luaA_screen_set_index_miss_handler },
	{ "set_newindex_miss_handler", luaA_screen_set_newindex_miss_handler },
	/* Class methods */
	{ "count", luaA_screen_count },
	{ "get", luaA_screen_get_by_index },
	/* NOTE: "primary" is NOT a method - it's a property handled by __index.
	 * AwesomeWM's screen.primary returns the primary screen object directly,
	 * not a function. The __index metamethod (luaA_screen_module_index)
	 * handles this at lines 1345-1358. */
	{ "_viewports", luaA_screen_viewports },
	{ "fake_add", luaA_screen_fake_add },
	/* Module-level metamethods */
	{ "__index", luaA_screen_module_index },
	{ "__call", luaA_screen_call },
	{ NULL, NULL }
};

/** Setup screen class (AwesomeWM pattern)
 * This registers the screen class as a global "screen" table
 * that can be accessed from Lua code.
 */
void
screen_class_setup(lua_State *L)
{
	/* Setup screen class using AwesomeWM's class system */
	luaA_class_setup(L, &screen_class, "screen", NULL,
	                 NULL, /* allocator - screens are created from C, not Lua */
	                 NULL, /* collector - screens are managed by compositor */
	                 (lua_class_checker_t) screen_checker,
	                 luaA_class_index_miss_property, luaA_class_newindex_miss_property,
	                 screen_methods, screen_meta);

	const lua_class_property_t properties[] = {
		{ "geometry", NULL, (lua_class_propfunc_t) luaA_screen_get_geometry_prop, NULL },
		{ "index", NULL, (lua_class_propfunc_t) luaA_screen_get_index_prop, NULL },
		{ "_outputs", NULL, (lua_class_propfunc_t) luaA_screen_get_outputs_prop, NULL },
		{ "_managed", NULL, (lua_class_propfunc_t) luaA_screen_get_managed_prop, NULL },
		{ "workarea", NULL, (lua_class_propfunc_t) luaA_screen_get_workarea_prop, NULL },
		{ "name", (lua_class_propfunc_t) luaA_screen_set_name, (lua_class_propfunc_t) luaA_screen_get_name_prop, (lua_class_propfunc_t) luaA_screen_set_name },
		{ "content", NULL, (lua_class_propfunc_t) luaA_screen_get_content, NULL },
		{ "scale", (lua_class_propfunc_t) luaA_screen_set_scale, (lua_class_propfunc_t) luaA_screen_get_scale, (lua_class_propfunc_t) luaA_screen_set_scale },
		{ "output", NULL, (lua_class_propfunc_t) luaA_screen_get_output, NULL },
	};
	luaA_class_add_properties(&screen_class, properties, countof(properties));
}
