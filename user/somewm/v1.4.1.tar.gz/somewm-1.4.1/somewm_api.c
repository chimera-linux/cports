/*
 * somewm_api.c - Public API implementation for somewm compositor
 *
 * This file implements the public API for interacting with the somewm
 * compositor from external modules (e.g., Lua bindings).
 */

#include <sys/wait.h>
#include <errno.h>
#include <string.h>
#include <math.h>
#include <glib.h>
#include <wlr/types/wlr_fractional_scale_v1.h>
#include <wlr/types/wlr_seat.h>
#include <wlr/types/wlr_keyboard_group.h>
#include <wlr/interfaces/wlr_keyboard.h>
#include <wlr/types/wlr_cursor.h>
#include <wlr/types/wlr_xcursor_manager.h>
#include <wlr/xwayland.h>

#include "somewm_api.h"
#include "xkb.h"
#include "objects/signal.h"
#include "objects/screen.h"
#include "stack.h"
#include "banning.h"
#include "globalconf.h"

/* Declare seat extern before including client.h */
extern struct wlr_seat *seat;
extern void *exclusive_focus;  /* Layer surface with exclusive keyboard focus */

/* External reference to globalconf (defined in somewm.c) */
extern awesome_t globalconf;

/* Include client.h for inline helper functions */
#include "client.h"

/*
 * External references to somewm.c globals and functions
 * These must be made non-static in somewm.c
 */
extern struct wl_list mons;
extern struct wlr_cursor *cursor;
extern struct wlr_xcursor_manager *cursor_mgr;
extern char *selected_root_cursor;
#ifdef XWAYLAND
extern struct wlr_xwayland *xwayland;
#endif
extern Monitor *selmon;
extern KeyboardGroup *kb_group;

/* Mirror of wlroots' private keyboard_group_device struct (wlr_keyboard_group.c).
 * Needed to iterate member keyboards when setting layout group.
 * Must match the exact layout of the wlroots 0.19 struct. */
struct kb_group_device {
	struct wlr_keyboard *keyboard;
	struct wl_listener key;
	struct wl_listener modifiers;
	struct wl_listener keymap;
	struct wl_listener repeat_info;
	struct wl_listener destroy;
	struct wl_list link;
};

/* Functions from somewm.c that need to be made non-static */
extern void focusclient(Client *c, int lift);
extern void motionnotify(uint32_t time, struct wlr_input_device *device,
		double dx, double dy, double dx_unaccel, double dy_unaccel);
/* setfloating() removed - Lua manages floating state */
extern void setfullscreen(Client *c, int fullscreen);
extern void arrange(Monitor *m);
extern void resize(Client *c, struct wlr_box geo, int interact);
extern Client *focustop(Monitor *m);
extern Monitor *xytomon(double x, double y);
extern void setmon(Client *c, Monitor *m, uint32_t newtags);
extern void xytonode(double x, double y, struct wlr_surface **psurface,
		Client **pc, LayerSurface **pl, drawin_t **pd, drawable_t **pdrawable,
		double *nx, double *ny);
extern Monitor *dirtomon(enum wlr_direction dir);
extern void focusmon(const Arg *arg);
extern void killclient(const Arg *arg);
extern void spawn(const Arg *arg);
extern void tile(Monitor *m);
extern void monocle(Monitor *m);
/* NOTE: moveresize() removed - move/resize now handled by Lua mousegrabber */
extern void togglefloating(const Arg *arg);
extern void setlayout(const Arg *arg);
extern void printstatus(void);
extern void zoom(const Arg *arg);
extern void swapstack(const Arg *arg);
extern void tagmon(const Arg *arg);

/* Settings from somewm.c */
extern int new_client_placement;

/* Scene & compositor state from somewm.c */
extern struct wlr_scene *scene;
extern struct wlr_scene_tree *layers[];
extern struct wlr_output_layout *output_layout;
extern struct wl_display *dpy;
extern struct wl_event_loop *event_loop;
extern struct wlr_layer_shell_v1 *layer_shell;
extern struct wlr_renderer *drw;
extern struct wlr_allocator *alloc;

/* Layouts now managed in Lua - no C layout functions needed */

/* Tag system helper functions from somewm.c */
extern int some_tagcount(void);
extern uint32_t some_tagmask(void);

/* Rules and MonitorRules helper functions from somewm.c */
extern size_t some_rules_length(void);
extern const Rule *some_get_rule_ptr(size_t index);
extern size_t some_monrules_length(void);
extern const MonitorRule *some_get_monrule_ptr(size_t index);

/*
 * Client API Implementation
 */

const char *
some_client_get_title(Client *c)
{
	if (!c)
		return NULL;
	return client_get_title(c);
}

const char *
some_client_get_appid(Client *c)
{
	if (!c)
		return NULL;
	return client_get_appid(c);
}

int
some_client_get_fullscreen(Client *c)
{
	return c ? c->fullscreen : 0;
}

int
some_client_get_urgent(Client *c)
{
	return c ? c->urgent : 0;
}

Monitor *
some_client_get_monitor(Client *c)
{
	return c ? c->mon : NULL;
}

void
some_client_get_geometry(Client *c, struct wlr_box *geom)
{
	if (!c || !geom)
		return;
	client_get_geometry(c, geom);
}

void
some_client_set_floating(Client *c, int floating)
{
	lua_State *L;

	if (!c)
		return;

	/* Set floating via Lua property system (AwesomeWM-compatible) */
	L = globalconf_get_lua_State();
	if (!L)
		return;

	luaA_object_push(L, c);
	lua_pushboolean(L, floating);
	lua_setfield(L, -2, "floating");
	lua_pop(L, 1);
}

void
some_client_set_fullscreen(Client *c, int fullscreen)
{
	if (!c)
		return;
	setfullscreen(c, fullscreen);
}

void
some_client_focus(Client *c, int lift)
{
	focusclient(c, lift);
}

void
some_client_close(Client *c)
{
	if (!c)
		return;
	client_send_close(c);
}

void
some_client_resize(Client *c, struct wlr_box geom, int interact)
{
	if (!c)
		return;
	resize(c, geom, interact);
}

void
some_client_kill(Client *c)
{
	Arg arg;
	if (!c)
		return;
	arg = (Arg){.v = (void *)c};
	killclient(&arg);
}

void
some_client_move_to_monitor(Client *c, Monitor *m, uint32_t tags)
{
	/* Simplified - tags parameter ignored */
	(void)tags;
	if (!c || !m)
		return;
	setmon(c, m, 0);
}

void
some_client_set_geometry(Client *c, int x, int y, int w, int h)
{
	struct wlr_box geom = {.x = x, .y = y, .width = w, .height = h};
	if (!c)
		return;
	resize(c, geom, 0);
}

void
some_client_move(Client *c, int x, int y)
{
	struct wlr_box geom;
	if (!c)
		return;
	some_client_get_geometry(c, &geom);
	geom.x = x;
	geom.y = y;
	resize(c, geom, 0);
}

void
some_client_zoom(void)
{
	Arg arg = {0};
	zoom(&arg);
}

void
some_client_swapstack(int direction)
{
	Arg arg = {.i = direction};
	swapstack(&arg);
}

Client *
some_get_focused_client(void)
{
	return globalconf.focus.client;
}

Client *
some_client_at(double lx, double ly)
{
	/* This is a simplified version - real implementation would need
	 * to use wlr_scene functions to find the client at coordinates */
	foreach(client, globalconf.clients) {
		Client *c = *client;
		if (c->geometry.x <= lx && lx < c->geometry.x + c->geometry.width &&
		    c->geometry.y <= ly && ly < c->geometry.y + c->geometry.height) {
			return c;
		}
	}
	return NULL;
}

/*
 * Monitor API Implementation
 */

void
some_monitor_get_geometry(Monitor *m, struct wlr_box *geom)
{
	if (!m || !geom)
		return;
	*geom = m->m;
}

void
some_monitor_get_window_area(Monitor *m, struct wlr_box *geom)
{
	if (!m || !geom)
		return;
	*geom = m->w;
}

void
some_monitor_arrange(Monitor *m)
{
	if (!m)
		return;
	arrange(m);
}

Monitor *
some_get_focused_monitor(void)
{
	return selmon;
}

struct wl_list *
some_get_monitors(void)
{
	return &mons;
}

Monitor *
some_monitor_at(double lx, double ly)
{
	return xytomon(lx, ly);
}

Monitor *
some_monitor_from_direction(Monitor *from, enum wlr_direction dir)
{
	if (!from)
		from = selmon;
	return dirtomon(dir);
}

void
some_focus_monitor(Monitor *m)
{
	Client *c;
	if (!m)
		return;
	/* Focus the topmost client on the monitor */
	c = focustop(m);
	if (c) {
		focusclient(c, 1);
	}
	selmon = m;
}

void
some_focus_monitor_direction(enum wlr_direction dir)
{
	Arg arg;
	arg.i = dir;
	focusmon(&arg);
}

void
some_move_client_to_monitor_direction(enum wlr_direction dir)
{
	Arg arg;
	arg.i = dir;
	tagmon(&arg);
}

/*
 * Spawn API Implementation
 */

void
some_spawn_command(const char *cmd)
{
	Arg arg;
	if (!cmd)
		return;
	arg = (Arg){.v = (const char *[]){ "/bin/sh", "-c", cmd, NULL }};
	spawn(&arg);
}

/*
 * Settings API Implementation
 */

int
some_get_new_client_placement(void)
{
	return new_client_placement;
}

void
some_set_new_client_placement(int placement)
{
	new_client_placement = placement;
}

/*
 * Layout API Implementation
 */

/* Layout functions removed - layouts now managed in Lua */

void
some_arrange_all(void)
{
	Monitor *m;
	wl_list_for_each(m, &mons, link)
		arrange(m);
}

/*
 * Global state accessors
 */

struct wlr_seat *
some_get_seat(void)
{
	return seat;
}

/** Update Wayland seat keyboard focus to match the given client.
 * This is the centralized seat focus update function called by client_focus().
 * It ensures seat keyboard focus stays synchronized with Awesome's client.focus.
 *
 * Guards against redundant updates to avoid unnecessary Wayland protocol traffic
 * and potential focus loops.
 *
 * \param c The client to give seat keyboard focus (or NULL to clear focus)
 */
void
some_set_seat_keyboard_focus(Client *c)
{
	struct wlr_surface *surface;
	struct wlr_keyboard *kb;
	int surface_ready;

	if (!c) {
		wlr_seat_keyboard_notify_clear_focus(seat);
		return;
	}

	surface = some_client_get_surface(c);
	if (!surface) {
		wlr_seat_keyboard_notify_clear_focus(seat);
		return;
	}

	/* Check if surface is ready for keyboard input.
	 * For XWayland clients, wlr_surface->mapped may be false at map time;
	 * use c->scene (set by mapnotify) as the readiness indicator instead. */
#ifdef XWAYLAND
	if (c->client_type == X11)
		surface_ready = (c->scene != NULL);
	else
#endif
		surface_ready = surface->mapped;

	if (!surface_ready) {
		/* Surface not ready - clear seat focus to prevent input going to old window.
		 * When surface maps, mapnotify() will re-deliver keyboard focus. */
		wlr_seat_keyboard_notify_clear_focus(seat);
		return;
	}

	if (seat->keyboard_state.focused_surface == surface) {
#ifdef XWAYLAND
		if (c->client_type == X11) {
			/* KWin pattern: force focus re-delivery for X11 clients.
			 * wlroots skips re-entry to the same surface, so we must
			 * deactivate→clear→re-enter to deliver a new FocusIn event.
			 * Safe because X11 clients don't use XDG popup grabs. */
			client_activate_surface(surface, 0);
			wlr_seat_keyboard_notify_clear_focus(seat);
		} else
#endif
			/* XDG: early return — re-entering the same surface is a
			 * no-op in wlroots, and the clear→re-enter cycle would
			 * disrupt active popup grabs. */
			return;
	}

#ifdef XWAYLAND
	/* Deactivate old surface if switching away from an X11 client */
	if (c->client_type == X11 && seat->keyboard_state.focused_surface)
		client_activate_surface(seat->keyboard_state.focused_surface, 0);

	/* Sway pattern: inform XWayland of the active seat on every focus
	 * change to an X11 client. Required for proper keyboard delivery. */
	if (c->client_type == X11) {
		extern struct wlr_xwayland *xwayland;
		wlr_xwayland_set_seat(xwayland, seat);
	}
#endif
	kb = wlr_seat_get_keyboard(seat);
	if (kb) {
		wlr_seat_keyboard_notify_enter(seat, surface,
		                               kb->keycodes,
		                               kb->num_keycodes,
		                               &kb->modifiers);
	} else {
		/* Send keyboard enter even without a keyboard device (Sway pattern).
		 * Needed for XWayland clients that may lack a keyboard device. */
		wlr_seat_keyboard_notify_enter(seat, surface, NULL, 0, NULL);
	}
#ifdef XWAYLAND
	/* Activate X11 surface after keyboard enter — sends FocusIn event.
	 * Safe because X11 clients use X11 popup mechanisms, not XDG grabs. */
	if (c->client_type == X11)
		client_activate_surface(surface, 1);
#endif
}

/** Find the Client* that owns a given wlr_surface.
 * Used to map from Wayland seat keyboard focus to Awesome client object.
 *
 * \param surface The wlr_surface to look up
 * \return The Client* owning the surface, or NULL if not found
 */
Client *
some_client_from_surface(struct wlr_surface *surface)
{
	if (!surface) {
		return NULL;
	}

	/* Search through all clients to find one whose surface matches.
	 * The foreach() macro declares elem internally. */
	foreach(elem, globalconf.clients) {
		if (client_surface(*elem) == surface) {
			return *elem;
		}
	}

	return NULL;
}

/** Check if a client has actual keyboard focus (wlroots seat focus).
 * This checks the real Wayland seat keyboard focus, not just Lua bookkeeping.
 * Use this in tests to verify keyboard input will actually go to the client.
 *
 * \param c The client to check
 * \return 1 if client has keyboard focus, 0 otherwise
 */
int
some_client_has_keyboard_focus(Client *c)
{
	struct wlr_surface *focused_surface;
	struct wlr_surface *client_surf;

	if (!c || !seat)
		return 0;

	focused_surface = seat->keyboard_state.focused_surface;
	if (!focused_surface)
		return 0;

	client_surf = some_client_get_surface(c);
	return (focused_surface == client_surf);
}

struct wlr_cursor *
some_get_cursor(void)
{
	return cursor;
}

/*
 * Cursor Theme API
 */

const char *
some_get_cursor_theme(void)
{
	return cursor_mgr->name ? cursor_mgr->name : "default";
}

uint32_t
some_get_cursor_size(void)
{
	return cursor_mgr->size;
}

void
some_update_cursor_theme(const char *theme_name, uint32_t size)
{
	Monitor *m;
	char *theme_copy = NULL;

	/* Copy theme name before destroying old manager (it may own the string) */
	if (theme_name) {
		theme_copy = strdup(theme_name);
	}

	/* Destroy old manager */
	wlr_xcursor_manager_destroy(cursor_mgr);

	/* Create new manager with specified theme/size */
	cursor_mgr = wlr_xcursor_manager_create(theme_copy, size);

	free(theme_copy);

	/* Reload cursor theme for each monitor's scale */
	wl_list_for_each(m, &mons, link) {
		wlr_xcursor_manager_load(cursor_mgr, m->wlr_output->scale);
	}

	/* Update displayed cursor - fall back to "default" if current cursor doesn't exist in new theme */
	const char *cursor_name = selected_root_cursor ? selected_root_cursor : "default";
	if (wlr_xcursor_manager_get_xcursor(cursor_mgr, cursor_name, 1.0) == NULL) {
		cursor_name = "default";
	}
	wlr_cursor_set_xcursor(cursor, cursor_mgr, cursor_name);

#ifdef XWAYLAND
	/* Sync XWayland cursor if running */
	struct wlr_xcursor *xcursor = wlr_xcursor_manager_get_xcursor(cursor_mgr, "default", 1);
	if (xcursor && xwayland) {
		wlr_xwayland_set_cursor(xwayland,
			xcursor->images[0]->buffer, xcursor->images[0]->width * 4,
			xcursor->images[0]->width, xcursor->images[0]->height,
			xcursor->images[0]->hotspot_x, xcursor->images[0]->hotspot_y);
	}
#endif
}

struct wl_list *
some_get_keyboard_groups(void)
{
	/* kb_group is a single KeyboardGroup, not a list, but included for API completeness */
	return NULL;
}

/*
 * Scene & compositor state accessors
 */

struct wlr_scene *
some_get_scene(void)
{
	return scene;
}

struct wlr_scene_tree **
some_get_layers(void)
{
	return layers;
}

struct wlr_output_layout *
some_get_output_layout(void)
{
	return output_layout;
}

struct wl_display *
some_get_display(void)
{
	return dpy;
}

struct wl_event_loop *
some_get_event_loop(void)
{
	return event_loop;
}

struct wlr_layer_shell_v1 *
some_get_layer_shell(void)
{
	return layer_shell;
}

struct wlr_renderer *
some_get_renderer(void)
{
	return drw;
}

struct wlr_allocator *
some_get_allocator(void)
{
	return alloc;
}

/*
 * Compositor Control API Implementation
 */

void
some_compositor_quit(void)
{
	if (globalconf.loop) {
		g_main_loop_quit(globalconf.loop);
	}
	wl_display_terminate(dpy);
}

/*
 * Enhanced Client API
 */

/* Client hierarchy */
Client *
some_client_get_parent(Client *c)
{
	if (!c)
		return NULL;
	return client_get_parent(c);
}

int
some_client_has_children(Client *c)
{
	if (!c)
		return 0;
	return client_has_children(c);
}

/* Visibility & state */
int
some_client_is_visible(Client *c, Monitor *m)
{
	/* Use array-based check instead of bitmask for AwesomeWM compatibility.
	 * Note: monitor parameter is kept for API compatibility, but the function
	 * now gets the monitor from the client itself. */
	(void)m; /* Unused - kept for API compatibility */
	return client_on_selected_tags(c) ? 1 : 0;
}

int
some_client_is_focused(Client *c)
{
	if (!c || !selmon)
		return 0;
	/* Check if this client is the top of the focus stack on the selected monitor */
	return (focustop(selmon) == c);
}

int
some_client_is_stopped(Client *c)
{
	if (!c)
		return 0;
	return client_is_stopped(c);
}

int
some_client_is_float_type(Client *c)
{
	if (!c)
		return 0;
	return client_is_float_type(c);
}

/* Get the floating state from Lua's authoritative property system.
 * This matches AwesomeWM's approach: C doesn't store floating state,
 * it always queries the Lua property which computes (explicit || implicit).
 * Returns 1 if floating, 0 if not, -1 on error.
 */
int
some_client_get_floating(Client *c)
{
	lua_State *L;
	int result = 0;

	if (!c)
		return 0;

	L = globalconf_get_lua_State();
	if (!L)
		return 0;

	/* Push client object onto stack */
	luaA_object_push(L, c);
	if (!lua_isuserdata(L, -1)) {
		lua_pop(L, 1);
		return 0;
	}

	/* Get the "floating" property: c.floating */
	lua_getfield(L, -1, "floating");
	if (lua_isboolean(L, -1)) {
		result = lua_toboolean(L, -1);
	} else if (lua_isnil(L, -1)) {
		/* floating property not set yet, assume false */
		result = 0;
	}

	/* Clean up stack */
	lua_pop(L, 2); /* pop boolean and client */

	return result;
}

/* Properties */
void
some_client_set_urgent(Client *c, int urgent)
{
	lua_State *L;

	if (!c)
		return;
	/* Use proper API for signal emission */
	L = globalconf_get_lua_State();
	luaA_object_push(L, c);
	client_set_urgent(L, -1, urgent);
	lua_pop(L, 1);
	printstatus();
}

void
some_client_set_border_width(Client *c, unsigned int bw)
{
	if (!c)
		return;
	c->bw = bw;
}

void
some_client_set_border_color(Client *c, const float color[4])
{
	if (!c || !color)
		return;
	client_set_border_color(c, color);
}

void
some_client_set_ontop(Client *c, int ontop)
{
	if (!c)
		return;
	c->ontop = ontop;
	stack_refresh();
}

void
some_client_set_above(Client *c, int above)
{
	if (!c)
		return;
	c->above = above;
	stack_refresh();
}

void
some_client_set_below(Client *c, int below)
{
	if (!c)
		return;
	c->below = below;
	stack_refresh();
}

void
some_client_set_window_type(Client *c, window_type_t window_type)
{
	if (!c)
		return;
	c->type = window_type;
	stack_refresh();
}

int
some_client_get_ontop(Client *c)
{
	return c ? c->ontop : 0;
}

int
some_client_get_above(Client *c)
{
	return c ? c->above : 0;
}

int
some_client_get_below(Client *c)
{
	return c ? c->below : 0;
}

window_type_t
some_client_get_window_type(Client *c)
{
	return c ? c->type : WINDOW_TYPE_NORMAL;
}

Client *
some_client_get_transient_for(Client *c)
{
	return c ? c->transient_for : NULL;
}


void
some_client_set_sticky(Client *c, int sticky)
{
	Monitor *m;

	if (!c || c->sticky == sticky)
		return;

	c->sticky = sticky;

	/* Sticky clients are visible on all tags, so arrange all monitors */
	wl_list_for_each(m, some_get_monitors(), link)
		arrange(m);

	/* Emit property change signal */
	luaA_emit_signal_global_with_client("client::property::sticky", c);
}

int
some_client_get_sticky(Client *c)
{
	return c ? c->sticky : 0;
}

void
some_client_set_minimized(Client *c, int minimized)
{
	if (!c || c->minimized == minimized)
		return;

	c->minimized = minimized;

	/* Minimized clients are unmapped from scene */
	if (c->scene && c->scene->node.enabled != !minimized)
		wlr_scene_node_set_enabled(&c->scene->node, !minimized);

	/* Update arrangements */
	if (c->mon)
		arrange(c->mon);

	/* Emit property change signal */
	luaA_emit_signal_global_with_client("client::property::minimized", c);
}

int
some_client_get_minimized(Client *c)
{
	return c ? c->minimized : 0;
}

void
some_client_set_hidden(Client *c, int hidden)
{
	if (!c || c->hidden == hidden)
		return;

	c->hidden = hidden;

	/* Hidden clients are not shown in scene */
	if (c->scene && c->scene->node.enabled != !hidden)
		wlr_scene_node_set_enabled(&c->scene->node, !hidden);

	/* Update arrangements */
	if (c->mon)
		arrange(c->mon);

	/* Emit property change signal */
	luaA_emit_signal_global_with_client("client::property::hidden", c);
}

int
some_client_get_hidden(Client *c)
{
	return c ? c->hidden : 0;
}

void
some_client_set_modal(Client *c, int modal)
{
	if (!c || c->modal == modal)
		return;

	c->modal = modal;

	/* Modal windows affect stacking */
	stack_refresh();

	/* Emit property change signal */
	luaA_emit_signal_global_with_client("client::property::modal", c);
}

int
some_client_get_modal(Client *c)
{
	return c ? c->modal : 0;
}

void
some_client_set_skip_taskbar(Client *c, int skip_taskbar)
{
	if (!c || c->skip_taskbar == skip_taskbar)
		return;

	c->skip_taskbar = skip_taskbar;

	/* Emit property change signal */
	luaA_emit_signal_global_with_client("client::property::skip_taskbar", c);
}

int
some_client_get_skip_taskbar(Client *c)
{
	return c ? c->skip_taskbar : 0;
}

void
some_client_set_focusable(Client *c, int focusable)
{
	if (!c)
		return;

	c->focusable = focusable;
	c->focusable_set = 1;

	/* Emit property change signal */
	luaA_emit_signal_global_with_client("client::property::focusable", c);
}

int
some_client_get_focusable(Client *c)
{
	if (!c)
		return 0;

	/* If explicitly set, use that value */
	if (c->focusable_set)
		return c->focusable;

	/* Default: most clients are focusable */
	return 1;
}

void
some_client_set_maximized(Client *c, int maximized)
{
	if (!c || c->maximized == maximized)
		return;

	c->maximized = maximized;

	if (maximized) {
		/* Maximized sets both horizontal and vertical */
		c->maximized_horizontal = 1;
		c->maximized_vertical = 1;

		/* Maximized is mutually exclusive with fullscreen */
		if (c->fullscreen)
			some_client_set_fullscreen(c, 0);

		/* Set XDG toplevel maximize state if applicable */
		if (c->client_type == XDGShell && c->surface.xdg->toplevel)
			wlr_xdg_toplevel_set_maximized(c->surface.xdg->toplevel, 1);
	} else {
		c->maximized_horizontal = 0;
		c->maximized_vertical = 0;

		/* Clear XDG toplevel maximize state if applicable */
		if (c->client_type == XDGShell && c->surface.xdg->toplevel)
			wlr_xdg_toplevel_set_maximized(c->surface.xdg->toplevel, 0);
	}

	/* Rearrange monitor to apply new geometry */
	if (c->mon)
		arrange(c->mon);

	/* Emit property change signals */
	luaA_emit_signal_global_with_client("client::property::maximized", c);
	luaA_emit_signal_global_with_client("client::property::maximized_horizontal", c);
	luaA_emit_signal_global_with_client("client::property::maximized_vertical", c);
}

int
some_client_get_maximized(Client *c)
{
	return c ? c->maximized : 0;
}

void
some_client_set_maximized_horizontal(Client *c, int maximized_horizontal)
{
	if (!c || c->maximized_horizontal == maximized_horizontal)
		return;

	c->maximized_horizontal = maximized_horizontal;

	/* Update combined maximized state */
	c->maximized = c->maximized_horizontal && c->maximized_vertical;

	if (maximized_horizontal && c->fullscreen)
		some_client_set_fullscreen(c, 0);

	/* Rearrange monitor to apply new geometry */
	if (c->mon)
		arrange(c->mon);

	/* Emit property change signal */
	luaA_emit_signal_global_with_client("client::property::maximized_horizontal", c);
	if (c->maximized)
		luaA_emit_signal_global_with_client("client::property::maximized", c);
}

int
some_client_get_maximized_horizontal(Client *c)
{
	return c ? c->maximized_horizontal : 0;
}

void
some_client_set_maximized_vertical(Client *c, int maximized_vertical)
{
	if (!c || c->maximized_vertical == maximized_vertical)
		return;

	c->maximized_vertical = maximized_vertical;

	/* Update combined maximized state */
	c->maximized = c->maximized_horizontal && c->maximized_vertical;

	if (maximized_vertical && c->fullscreen)
		some_client_set_fullscreen(c, 0);

	/* Rearrange monitor to apply new geometry */
	if (c->mon)
		arrange(c->mon);

	/* Emit property change signal */
	luaA_emit_signal_global_with_client("client::property::maximized_vertical", c);
	if (c->maximized)
		luaA_emit_signal_global_with_client("client::property::maximized", c);
}

int
some_client_get_maximized_vertical(Client *c)
{
	return c ? c->maximized_vertical : 0;
}

/* Stack manipulation */
void
some_client_raise(Client *c)
{
	if (!c)
		return;
	stack_client_append(c);
	stack_refresh();
}

void
some_client_lower(Client *c)
{
	if (!c)
		return;
	stack_client_push(c);
	stack_refresh();
}

/* Surface access */
struct wlr_surface *
some_client_get_surface(Client *c)
{
	if (!c)
		return NULL;
	return client_surface(c);
}

const char *
some_client_get_name(Client *c)
{
	if (!c)
		return NULL;
	return c->name;
}

const char *
some_client_get_class(Client *c)
{
	if (!c)
		return NULL;
	return c->class;
}

const char *
some_client_get_instance(Client *c)
{
	if (!c)
		return NULL;
	return c->instance;
}

const char *
some_client_get_role(Client *c)
{
	if (!c)
		return NULL;
	return c->role;
}

const char *
some_client_get_machine(Client *c)
{
	if (!c)
		return NULL;
	return c->machine;
}

const char *
some_client_get_startup_id(Client *c)
{
	if (!c)
		return NULL;
	return c->startup_id;
}

const char *
some_client_get_icon_name(Client *c)
{
	if (!c)
		return NULL;
	return c->icon_name;
}

uint32_t
some_client_get_pid(Client *c)
{
	return c ? c->pid : 0;
}

/** some_client_update_metadata - Update cached metadata from surface
 * This should be called when a client is created or when surface properties change.
 * Reads properties from the underlying Wayland/X11 surface and caches them.
 */
void
some_client_update_metadata(Client *c)
{
	struct wlr_xdg_toplevel *toplevel;

	if (!c)
		return;

	/* Free old cached values */
	free(c->name);
	free(c->class);
	free(c->instance);
	free(c->role);
	free(c->machine);
	free(c->startup_id);
	free(c->icon_name);
	c->name = c->class = c->instance = c->role = NULL;
	c->machine = c->startup_id = c->icon_name = NULL;
	c->pid = 0;

	/* Update based on client type */
	if (c->client_type == XDGShell) {
		struct wl_client *wl_client;
		struct wlr_surface *surface;

		toplevel = c->surface.xdg->toplevel;

		/* Window title from XDG toplevel */
		if (toplevel->title)
			c->name = strdup(toplevel->title);

		/* app_id is the Wayland equivalent of WM_CLASS */
		if (toplevel->app_id)
			c->class = strdup(toplevel->app_id);

		/* Get PID from wl_client */
		surface = c->surface.xdg->surface;
		if (surface && surface->resource) {
			pid_t pid;
			wl_client = wl_resource_get_client(surface->resource);
			wl_client_get_credentials(wl_client, &pid, NULL, NULL);
			c->pid = (uint32_t)pid;
		}

		/* instance and role don't exist in Wayland (X11 only) */
		c->instance = NULL;
		c->role = NULL;
	}
#ifdef XWAYLAND
	else if (c->client_type == X11) {
		/* X11 clients: read properties from X11 */
		/* WM_NAME (window title) */
		if (c->surface.xwayland->title)
			c->name = strdup(c->surface.xwayland->title);

		/* WM_CLASS (class and instance) */
		if (c->surface.xwayland->class)
			c->class = strdup(c->surface.xwayland->class);
		if (c->surface.xwayland->instance)
			c->instance = strdup(c->surface.xwayland->instance);

		/* PID */
		c->pid = c->surface.xwayland->pid;

		/* For more detailed X11 properties, we'd need xcb queries
		 * but role and machine are rarely used, so skip for now */
		c->role = NULL;
		c->machine = NULL;
	}
#endif

	/* Emit property change signals for metadata that changed */
	luaA_emit_signal_global_with_client("client::property::name", c);
	luaA_emit_signal_global_with_client("client::property::class", c);
	luaA_emit_signal_global_with_client("client::property::instance", c);
	luaA_emit_signal_global_with_client("client::property::pid", c);
}

/*
 * Tag System API Implementation
 */

/* Tag constants */
int
some_get_tag_count(void)
{
	return some_tagcount();
}

uint32_t
some_get_tag_mask(void)
{
	return some_tagmask();
}

/*
 * Config Array Access API Implementation
 */

/*
 * Get monitor output name (e.g., "HDMI-A-1", "eDP-1")
 */
const char *
some_get_monitor_name(Monitor *m)
{
	if (!m || !m->wlr_output)
		return NULL;
	return m->wlr_output->name;
}

/*
 * Get monitor under cursor position
 */
Monitor *
some_monitor_at_cursor(void)
{
	if (!cursor)
		return NULL;
	return xytomon(cursor->x, cursor->y);
}

/*
 * Get current cursor position
 */
void
some_get_cursor_position(double *x, double *y)
{
	if (!cursor) {
		if (x) *x = 0.0;
		if (y) *y = 0.0;
		return;
	}
	if (x) *x = cursor->x;
	if (y) *y = cursor->y;
}

/*
 * Start interactive move of focused client
 * NOTE: This is now a no-op - move/resize is handled by Lua mousegrabber
 * via awful.mouse.client.move() called from client button bindings in rc.lua
 */
void
some_client_start_move(void)
{
	/* No-op: Lua mousegrabber handles move */
}

/*
 * Start interactive resize of focused client
 * NOTE: This is now a no-op - move/resize is handled by Lua mousegrabber
 * via awful.mouse.client.resize() called from client button bindings in rc.lua
 */
void
some_client_start_resize(void)
{
	/* No-op: Lua mousegrabber handles resize */
}

/*
 * Toggle floating mode for focused client
 */
void
some_client_togglefloating(void)
{
	Arg arg = {0};
	togglefloating(&arg);
}

/*
 * Set cursor position (warp cursor)
 * If silent is true, motion events are suppressed
 */
void
some_set_cursor_position(double x, double y, int silent)
{
	if (!cursor)
		return;

	/* If silent mode, set flag to suppress enter/leave events on next motion */
	if (silent) {
		globalconf.mouse_under.ignore_next_enter_leave = true;
	}

	wlr_cursor_warp(cursor, NULL, x, y);
}

/*
 * Inject a fake relative pointer motion through the full compositor path.
 * Unlike raw wlr_cursor_move(), this calls motionnotify() which handles
 * selmon tracking, pointer focus, Lua signals, and constraint processing.
 */
void
some_fake_motion(double dx, double dy)
{
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	uint32_t time = (uint32_t)(ts.tv_sec * 1000 + ts.tv_nsec / 1000000);
	motionnotify(time, NULL, dx, dy, dx, dy);
}

/*
 * Get mouse button states
 * Returns pressed state for buttons 1-5 (left, middle, right, side1, side2)
 * Button mapping: BTN_LEFT=1, BTN_MIDDLE=2, BTN_RIGHT=3, BTN_SIDE=4, BTN_EXTRA=5
 *
 * NOTE: We use globalconf.button_state which is tracked in buttonpress(),
 * NOT seat->pointer_state. This is critical for mousegrabber to work correctly.
 * The seat's pointer state only tracks buttons when focused on a surface,
 * but during compositor-level grabs (like window move/resize) there may be
 * no focused surface. globalconf.button_state is always accurate.
 */
void
some_get_button_states(int states[5])
{
	int i;

	if (!states)
		return;

	/* Read from globalconf.button_state which is updated in buttonpress() */
	for (i = 0; i < 5; i++)
		states[i] = globalconf.button_state.buttons[i] ? 1 : 0;
}

/*
 * Get object (client or layer surface) under cursor
 * Returns client pointer if cursor is over a client window
 * Returns NULL if cursor is over background or layer surface
 */
Client *
some_object_under_cursor(void)
{
	if (!cursor)
		return NULL;

	/* Use existing some_client_at function */
	return some_client_at(cursor->x, cursor->y);
}

/*
 * Get drawin under cursor position
 * Returns drawin_t pointer or NULL if no drawin under cursor
 */
drawin_t *
some_drawin_under_cursor(void)
{
	drawin_t *d = NULL;

	if (!cursor)
		return NULL;

	/* Use xytonode to find drawin at cursor position */
	xytonode(cursor->x, cursor->y, NULL, NULL, NULL, &d, NULL, NULL, NULL);

	return d;
}

/*
 * Warp cursor to center of specified monitor
 */
void
some_warp_cursor_to_monitor(Monitor *m)
{
	struct wlr_box box;
	extern struct wlr_output_layout *output_layout;

	if (!m || !m->wlr_output || !cursor)
		return;

	/* Get monitor geometry from output layout */
	wlr_output_layout_get_box(output_layout, m->wlr_output, &box);

	/* Warp to center of monitor */
	wlr_cursor_warp(cursor, NULL,
		box.x + box.width / 2,
		box.y + box.height / 2);
}

/*
 * Apply drawin struts (from Lua wibars) to a usable area
 * This is called from arrangelayers() to preserve wibar struts
 */
void
some_monitor_apply_drawin_struts(Monitor *m, struct wlr_box *area)
{
	extern lua_State *globalconf_L;

	if (!globalconf_L || !m || !area)
		return;

	luaA_monitor_apply_drawin_struts(globalconf_L, m, area);
}

/*
 * Focus a client
 */
void
some_focus_client(Client *c, int lift)
{
	focusclient(c, lift);
}

/*
 * Get the top focusable client on a monitor and focus it
 * Returns the focused client
 */
Client *
some_focus_top_client(Monitor *m)
{
	Client *c = focustop(m);
	if (c)
		focusclient(c, 1);
	return c;
}

/*
 * XKB Keyboard Layout API
 *
 * TODO: XKB toggle options (grp:rctrl_toggle, grp:alt_shift_toggle, etc.) don't
 * trigger layout changes via key presses. The API functions work correctly, but
 * xkbcommon's built-in toggle handling isn't being activated by wlroots keyboard
 * group key events. Needs investigation into wlr_keyboard_group's xkb_state
 * update path. Workaround: use keybindings that call xkb_set_layout_group().
 */

/* Get the current xkb_state from the keyboard group */
struct xkb_state *
some_xkb_get_state(void)
{
	if (!kb_group || !kb_group->wlr_group)
		return NULL;
	return kb_group->wlr_group->keyboard.xkb_state;
}

/* Get the current xkb_keymap from the keyboard group */
struct xkb_keymap *
some_xkb_get_keymap(void)
{
	if (!kb_group || !kb_group->wlr_group)
		return NULL;
	return kb_group->wlr_group->keyboard.keymap;
}

/* Set the keyboard layout group.
 *
 * Strategy: use wlr_keyboard_notify_modifiers() on member keyboards.
 * This is the same path wlroots uses internally for grp:alt_shift_toggle.
 * It properly updates the member's xkb_state, syncs modifiers, and
 * propagates through handle_keyboard_modifiers() to the group keyboard,
 * which then reaches somewm's keypressmod() and the client.
 *
 * Previous approach (manual xkb_state_update_mask + struct patching)
 * failed because wlr_keyboard_notify_key() on the member would later
 * call keyboard_modifier_update() which re-serialized from xkb_state,
 * and the member's xkb_state could drift out of sync.
 *
 * Returns 1 on success, 0 on failure.
 */
int
some_xkb_set_layout_group(xkb_layout_index_t group)
{
	if (!kb_group || !kb_group->wlr_group)
		return 0;

	struct wlr_keyboard *kbd = &kb_group->wlr_group->keyboard;

	if (!kbd->xkb_state || !kbd->keymap)
		return 0;

	/* Validate group index */
	xkb_layout_index_t num_layouts = xkb_keymap_num_layouts(kbd->keymap);
	if (group >= num_layouts)
		return 0;

	xkb_layout_index_t old_group = xkb_state_serialize_layout(
		kbd->xkb_state, XKB_STATE_LAYOUT_EFFECTIVE);

	if (old_group == group)
		return 1; /* Already at requested group */

	/* Sway pattern: call wlr_keyboard_notify_modifiers() on each member.
	 * This updates the member's xkb_state via xkb_state_update_mask(),
	 * syncs the modifiers struct, and emits the modifiers signal.
	 * wlroots' handle_keyboard_modifiers() then propagates to the group
	 * keyboard, which fires keypressmod() → client notification. */
	int member_count = 0;
	struct kb_group_device *dev;
	wl_list_for_each(dev, &kb_group->wlr_group->devices, link) {
		struct wlr_keyboard *member = dev->keyboard;
		if (member->xkb_state) {
			wlr_keyboard_notify_modifiers(member,
				xkb_state_serialize_mods(member->xkb_state, XKB_STATE_MODS_DEPRESSED),
				xkb_state_serialize_mods(member->xkb_state, XKB_STATE_MODS_LATCHED),
				xkb_state_serialize_mods(member->xkb_state, XKB_STATE_MODS_LOCKED),
				group);
			member_count++;
		}
	}

	/* Fallback: update group keyboard directly if no members */
	if (member_count == 0) {
		wlr_keyboard_notify_modifiers(kbd,
			xkb_state_serialize_mods(kbd->xkb_state, XKB_STATE_MODS_DEPRESSED),
			xkb_state_serialize_mods(kbd->xkb_state, XKB_STATE_MODS_LATCHED),
			xkb_state_serialize_mods(kbd->xkb_state, XKB_STATE_MODS_LOCKED),
			group);
	}

	/* Client notification happens via keypressmod() — the wlroots cascade
	 * above triggers the group keyboard's modifiers signal, which fires
	 * keypressmod() → wlr_seat_keyboard_notify_modifiers(). */

	/* Emit Lua signal if layout actually changed */
	xkb_layout_index_t new_group = xkb_state_serialize_layout(
		kbd->xkb_state, XKB_STATE_LAYOUT_EFFECTIVE);
	if (old_group != new_group) {
		globalconf.xkb.last_group = new_group;
		xkb_schedule_group_changed();
	}

	return 1;
}

/* Get the XKB group names/symbols string.
 * Returns a static buffer with format like "pc+us+cz(qwerty):2+grp:alt_shift_toggle".
 * Uses RMLVO short codes (e.g. "us", "cz") so the keyboardlayout widget
 * can look them up in its xkeyboard_country_code table.
 */
const char *
some_xkb_get_group_names(void)
{
	static char symbols_buffer[512];
	size_t offset = 0;

	if (!kb_group || !kb_group->wlr_group)
		return NULL;

	if (!kb_group->wlr_group->keyboard.keymap)
		return NULL;

	/* Start with "pc" prefix (matches XKB convention) */
	offset = snprintf(symbols_buffer, sizeof(symbols_buffer), "pc");

	const char *layout_str = globalconf.keyboard.xkb_layout;
	const char *variant_str = globalconf.keyboard.xkb_variant;

	if (layout_str && *layout_str) {
		/* Build from RMLVO components: short codes that the widget expects.
		 * Layout string is comma-separated, e.g. "us,cz"
		 * Variant string is comma-separated, e.g. ",qwerty" (empty = no variant) */
		char layout_buf[256], variant_buf[256];
		char *layouts[32], *variants[32];
		int nlayouts = 0, nvariants = 0;
		char *p, *comma;

		snprintf(layout_buf, sizeof(layout_buf), "%s", layout_str);
		snprintf(variant_buf, sizeof(variant_buf), "%s",
		         variant_str ? variant_str : "");

		/* Split layouts by comma */
		p = layout_buf;
		while (nlayouts < 32) {
			layouts[nlayouts++] = p;
			comma = strchr(p, ',');
			if (!comma) break;
			*comma = '\0';
			p = comma + 1;
		}

		/* Split variants by comma (preserving empty fields) */
		p = variant_buf;
		while (nvariants < 32) {
			variants[nvariants++] = p;
			comma = strchr(p, ',');
			if (!comma) break;
			*comma = '\0';
			p = comma + 1;
		}

		for (int i = 0; i < nlayouts && offset < sizeof(symbols_buffer) - 1; i++) {
			const char *variant = (i < nvariants) ? variants[i] : "";
			int has_variant = variant && *variant;
			int group_idx = i + 1;

			if (has_variant && i > 0)
				offset += snprintf(symbols_buffer + offset,
				                   sizeof(symbols_buffer) - offset,
				                   "+%s(%s):%d", layouts[i], variant, group_idx);
			else if (has_variant)
				offset += snprintf(symbols_buffer + offset,
				                   sizeof(symbols_buffer) - offset,
				                   "+%s(%s)", layouts[i], variant);
			else if (i > 0)
				offset += snprintf(symbols_buffer + offset,
				                   sizeof(symbols_buffer) - offset,
				                   "+%s:%d", layouts[i], group_idx);
			else
				offset += snprintf(symbols_buffer + offset,
				                   sizeof(symbols_buffer) - offset,
				                   "+%s", layouts[i]);
		}
	} else {
		/* No RMLVO layout configured - fall back to keymap layout names */
		struct xkb_keymap *keymap = kb_group->wlr_group->keyboard.keymap;
		xkb_layout_index_t num_layouts = xkb_keymap_num_layouts(keymap);

		for (xkb_layout_index_t i = 0; i < num_layouts &&
		     offset < sizeof(symbols_buffer) - 1; i++) {
			const char *name = xkb_keymap_layout_get_name(keymap, i);
			if (name) {
				offset += snprintf(symbols_buffer + offset,
				                   sizeof(symbols_buffer) - offset,
				                   "+%s", name);
			}
		}
	}

	/* Append XKB options if configured */
	if (globalconf.keyboard.xkb_options &&
	    *globalconf.keyboard.xkb_options &&
	    offset < sizeof(symbols_buffer) - 1) {
		offset += snprintf(symbols_buffer + offset,
		                   sizeof(symbols_buffer) - offset,
		                   "+%s", globalconf.keyboard.xkb_options);
	}

	return symbols_buffer;
}

/* External references needed for keymap rebuild */
extern struct wl_event_loop *some_get_event_loop(void);

/* Rebuild the keyboard keymap from current globalconf settings */
void
some_rebuild_keyboard_keymap(void)
{
	struct xkb_context *context;
	struct xkb_keymap *keymap;
	struct xkb_rule_names rules = {0};

	if (!kb_group || !kb_group->wlr_group)
		return;

	context = xkb_context_new(XKB_CONTEXT_NO_FLAGS);
	if (!context)
		return;

	rules.layout = globalconf.keyboard.xkb_layout;
	rules.variant = globalconf.keyboard.xkb_variant;
	rules.options = globalconf.keyboard.xkb_options;

	keymap = xkb_keymap_new_from_names(context, &rules,
	                                   XKB_KEYMAP_COMPILE_NO_FLAGS);
	if (keymap) {
		wlr_keyboard_set_keymap(&kb_group->wlr_group->keyboard, keymap);

		/* Sync keymap to member keyboards. Without this, members keep
		 * their original single-layout keymap and can't switch groups. */
		struct kb_group_device *dev;
		wl_list_for_each(dev, &kb_group->wlr_group->devices, link) {
			if (dev->keyboard->keymap != keymap) {
				wlr_keyboard_set_keymap(dev->keyboard, keymap);
			}
		}

		xkb_keymap_unref(keymap);
		xkb_schedule_map_changed();
	}

	xkb_context_unref(context);
}

/* Enable or disable NumLock by toggling the Mod2 locked modifier.
 * This is the Sway pattern: after keymap creation, use
 * wlr_keyboard_notify_modifiers() to set the locked modifier state. */
void
some_set_numlock(int enabled)
{
	struct wlr_keyboard *kbd;
	xkb_mod_index_t mod2_idx;
	xkb_mod_mask_t locked_mods;

	if (!kb_group || !kb_group->wlr_group)
		return;

	kbd = &kb_group->wlr_group->keyboard;
	if (!kbd->keymap || !kbd->xkb_state)
		return;

	mod2_idx = xkb_keymap_mod_get_index(kbd->keymap, XKB_MOD_NAME_NUM);
	if (mod2_idx == XKB_MOD_INVALID)
		return;

	locked_mods = xkb_state_serialize_mods(kbd->xkb_state,
		XKB_STATE_MODS_LOCKED);

	if (enabled)
		locked_mods |= (1u << mod2_idx);
	else
		locked_mods &= ~(1u << mod2_idx);

	/* Apply to member keyboards (Sway pattern) */
	struct kb_group_device *dev;
	int member_count = 0;
	wl_list_for_each(dev, &kb_group->wlr_group->devices, link) {
		struct wlr_keyboard *member = dev->keyboard;
		if (member->xkb_state) {
			xkb_layout_index_t group = xkb_state_serialize_layout(
				member->xkb_state, XKB_STATE_LAYOUT_EFFECTIVE);
			wlr_keyboard_notify_modifiers(member,
				xkb_state_serialize_mods(member->xkb_state,
					XKB_STATE_MODS_DEPRESSED),
				xkb_state_serialize_mods(member->xkb_state,
					XKB_STATE_MODS_LATCHED),
				locked_mods, group);
			member_count++;
		}
	}

	/* Fallback: update group keyboard directly if no members */
	if (member_count == 0) {
		xkb_layout_index_t group = xkb_state_serialize_layout(
			kbd->xkb_state, XKB_STATE_LAYOUT_EFFECTIVE);
		wlr_keyboard_notify_modifiers(kbd,
			xkb_state_serialize_mods(kbd->xkb_state,
				XKB_STATE_MODS_DEPRESSED),
			xkb_state_serialize_mods(kbd->xkb_state,
				XKB_STATE_MODS_LATCHED),
			locked_mods, group);
	}

	wlr_log(WLR_INFO, "[KEYBOARD] NumLock %s", enabled ? "ON" : "OFF");
}

/* Apply keyboard repeat info from current globalconf settings */
void
some_apply_keyboard_repeat_info(void)
{
	if (!kb_group || !kb_group->wlr_group)
		return;

	wlr_keyboard_set_repeat_info(&kb_group->wlr_group->keyboard,
		globalconf.keyboard.repeat_rate, globalconf.keyboard.repeat_delay);
}

/*
 * Layer Surface Focus API
 */

void
layer_surface_grant_keyboard(LayerSurface *ls)
{
	if (!ls || !ls->layer_surface || !ls->mapped)
		return;

	/* Deactivate the focused client */
	focusclient(NULL, 0);

	/* Set as exclusive focus */
	exclusive_focus = ls;

	/* Send keyboard enter to the layer surface */
	client_notify_enter(ls->layer_surface->surface, wlr_seat_get_keyboard(seat));
}

void
layer_surface_revoke_keyboard(LayerSurface *ls)
{
	if (!ls)
		return;

	/* Only revoke if this surface currently has exclusive focus */
	if (exclusive_focus == ls) {
		exclusive_focus = NULL;

		/* Explicitly clear keyboard focus from the layer surface */
		wlr_seat_keyboard_notify_clear_focus(seat);

		/* Refocus the top client on the selected monitor */
		focusclient(focustop(selmon), 1);
	}
}
